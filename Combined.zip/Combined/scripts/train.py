from __future__ import annotations

import argparse
from pathlib import Path

from diffeo_sreps.models.neural_ode import MissingDeepDependencyError
from diffeo_sreps.training import SyntheticNeuralODETrainConfig, train_synthetic_neural_ode
from diffeo_sreps.utils import RunLogger, load_yaml


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="PowerPoint-aligned Neural ODE training entrypoint.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--gpu", default="0")
    parser.add_argument("--distributed", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    train_cfg = load_yaml(args.config)
    model_cfg = load_yaml(train_cfg["model_config"])
    output_dir = Path(train_cfg["output_dir"])
    logger = RunLogger(Path("outputs/logs") / output_dir.name)
    epoch_log_csv = Path("outputs/logs") / output_dir.name / "epoch_losses.csv"
    config = SyntheticNeuralODETrainConfig(
        data_config_path=str(train_cfg["data_config"]),
        latent_dim=int(model_cfg.get("latent_dim", 1024)),
        hidden_dim=int(model_cfg["hidden_dim"]),
        depth=int(model_cfg["num_layers"]),
        ode_steps=int(model_cfg["ode_steps"]),
        ode_method=str(model_cfg["ode_solver"]),
        time_embedding=str(model_cfg.get("time_embedding", "scalar")),
        stationary=bool(model_cfg.get("stationary", False)),
        batch_size=int(train_cfg["batch_size"]),
        epochs=int(train_cfg["epochs"]),
        learning_rate=float(train_cfg["lr"]),
        weight_decay=float(train_cfg["weight_decay"]),
        output_dir=str(output_dir),
        device=f"cuda:{args.gpu}" if args.gpu != "cpu" else "cpu",
        distributed=bool(args.distributed),
        epoch_log_csv=str(epoch_log_csv),
        loss_weights={k: float(v) for k, v in train_cfg.get("loss_weights", {}).items()},
        early_stopping_patience=int(train_cfg.get("early_stopping_patience", 10)),
        amp=bool(train_cfg.get("amp", False)),
        seed=int(train_cfg.get("seed", 0)),
    )
    logger.log(event="train_start", config=args.config, gpu=args.gpu, distributed=args.distributed)
    try:
        result = train_synthetic_neural_ode(config)
    except MissingDeepDependencyError as exc:
        raise SystemExit(str(exc)) from exc
    logger.log(
        event="train_end",
        best_checkpoint=str(result.best_checkpoint),
        final_train_loss=result.final_train_loss,
        final_val_loss=result.final_val_loss,
        device=result.device,
        distributed=result.distributed,
    )
    logger.write_summary(
        {
            "best_checkpoint": str(result.best_checkpoint),
            "final_train_loss": result.final_train_loss,
            "final_val_loss": result.final_val_loss,
            "device": result.device,
            "distributed": result.distributed,
        }
    )


if __name__ == "__main__":
    main()
