from __future__ import annotations

import time
from pathlib import Path

import numpy as np

from diffeo_sreps.data import generate_dataset_bundle, save_dataset_bundle
from diffeo_sreps.metrics import chamfer_distance, hausdorff_distance, landmark_rmse
from diffeo_sreps.render import render_registration
from diffeo_sreps.utils import load_yaml, write_csv, write_json


def ensure_bundle(data_config_path: str) -> tuple[dict, dict[str, dict[str, np.ndarray]], Path]:
    data_cfg = load_yaml(data_config_path)
    output_path = Path(data_cfg["output_path"])
    if output_path.exists():
        bundle = load_dataset_bundle(output_path)
    else:
        bundle = generate_dataset_bundle(data_cfg)
        save_dataset_bundle(bundle, output_path)
    return data_cfg, bundle, output_path


def load_dataset_bundle(path: str | Path) -> dict[str, dict[str, np.ndarray]]:
    raw = np.load(path, allow_pickle=True)
    bundle: dict[str, dict[str, np.ndarray]] = {}
    for flat_key in raw.files:
        split, key = flat_key.split("__", 1)
        bundle.setdefault(split, {})[key] = raw[flat_key]
    return bundle


def valid_target_points(target_points: np.ndarray) -> np.ndarray:
    mask = ~np.isnan(target_points).any(axis=1)
    return target_points[mask]


def pointwise_rmse_if_possible(pred: np.ndarray, target_padded: np.ndarray) -> float:
    valid_mask = ~np.isnan(target_padded).any(axis=1)
    if np.all(valid_mask):
        return landmark_rmse(pred, target_padded)
    return float("nan")


def estimate_jacobian_metrics(map_points, source_points: np.ndarray, sample_count: int = 8, eps: float = 1e-3) -> dict:
    n = source_points.shape[0]
    indices = np.linspace(0, n - 1, min(sample_count, n), dtype=int)
    dets = []
    for idx in indices:
        x = source_points[idx : idx + 1]
        jac = np.zeros((3, 3), dtype=float)
        for axis in range(3):
            delta = np.zeros((1, 3), dtype=float)
            delta[0, axis] = eps
            y_plus = map_points(x + delta)[0]
            y_minus = map_points(x - delta)[0]
            jac[:, axis] = (y_plus - y_minus) / (2.0 * eps)
        dets.append(float(np.linalg.det(jac)))
    dets = np.asarray(dets, dtype=float)
    return {
        "jacobian_positive_rate": float(np.mean(dets > 0.0)),
        "jacobian_min_det": float(np.min(dets)),
        "fold_fraction": float(np.mean(dets <= 0.0)),
    }


def summarize_rows(rows: list[dict], metric_keys: list[str]) -> dict:
    summary = {"num_samples": len(rows)}
    for key in metric_keys:
        values = np.asarray([row[key] for row in rows if not np.isnan(row[key])], dtype=float)
        if values.size:
            summary[f"{key}_mean"] = float(np.mean(values))
            summary[f"{key}_median"] = float(np.median(values))
        else:
            summary[f"{key}_mean"] = float("nan")
            summary[f"{key}_median"] = float("nan")
    return summary


def maybe_render_examples(rows: list[dict], split_data: dict[str, np.ndarray], predictions: list[np.ndarray], output_dir: Path):
    figure_dir = Path("outputs/figures") / output_dir.name
    for i in range(min(3, len(predictions))):
        render_registration(
            split_data["source_points"][i],
            valid_target_points(split_data["target_points"][i]),
            pred=predictions[i],
            save_path=figure_dir / f"example_{i:02d}.png",
        )


def record_runtime(start_time: float) -> float:
    return time.perf_counter() - start_time


def save_eval_outputs(output_dir: Path, rows: list[dict], summary: dict) -> tuple[Path, Path]:
    metrics_path = write_csv(rows, output_dir / "per_sample_metrics.csv")
    summary_path = write_json(summary, output_dir / "summary.json")
    return metrics_path, summary_path
