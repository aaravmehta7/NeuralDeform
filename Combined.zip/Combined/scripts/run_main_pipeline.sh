#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python}"
GPU_ARG="${1:-0}"
TRAIN_CONFIG="configs/train/main.yaml"
DATA_CONFIG="$(awk -F': ' '/^data_config:/{print $2; exit}' "$TRAIN_CONFIG")"

cd "$ROOT_DIR"

export PYTHONPATH="$ROOT_DIR/src"
export PYTHONUNBUFFERED=1

log_stage() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] stage=$1"
}

log_stage generate_data
"$PYTHON_BIN" scripts/generate_data.py --config "$DATA_CONFIG"
log_stage train
"$PYTHON_BIN" scripts/train.py --config "$TRAIN_CONFIG" --gpu "$GPU_ARG"
log_stage eval_in_domain
"$PYTHON_BIN" scripts/eval_model.py --checkpoint outputs/checkpoints/presentation_experiment2/best_model.pt --config configs/eval/in_domain.yaml
log_stage eval_ood_strong
"$PYTHON_BIN" scripts/eval_model.py --checkpoint outputs/checkpoints/presentation_experiment2/best_model.pt --config configs/eval/ood_strong.yaml
log_stage eval_ood_shape
"$PYTHON_BIN" scripts/eval_model.py --checkpoint outputs/checkpoints/presentation_experiment2/best_model.pt --config configs/eval/ood_shape.yaml
log_stage eval_ood_noise
"$PYTHON_BIN" scripts/eval_model.py --checkpoint outputs/checkpoints/presentation_experiment2/best_model.pt --config configs/eval/ood_noise.yaml
log_stage eval_baseline
"$PYTHON_BIN" scripts/eval_baseline.py --config configs/eval/in_domain.yaml
log_stage render_examples
"$PYTHON_BIN" scripts/render_examples.py --checkpoint outputs/checkpoints/presentation_experiment2/best_model.pt --split test_in_domain --config configs/eval/in_domain.yaml
log_stage summarize_results
"$PYTHON_BIN" scripts/summarize_results.py --results_dir outputs
log_stage complete
