from __future__ import annotations

import argparse
import time
from pathlib import Path

import numpy as np

from _eval_common import (
    ensure_bundle,
    estimate_jacobian_metrics,
    maybe_render_examples,
    pointwise_rmse_if_possible,
    record_runtime,
    save_eval_outputs,
    summarize_rows,
    valid_target_points,
)
from diffeo_sreps.baselines import LandmarkLDDMM
from diffeo_sreps.metrics import chamfer_distance, hausdorff_distance
from diffeo_sreps.utils import load_yaml


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate the landmark-style LDDMM baseline.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--limit", type=int, default=None)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    eval_cfg = load_yaml(args.config)
    _, bundle, _ = ensure_bundle(eval_cfg["data_config"])
    split = eval_cfg["split"]
    split_data = bundle[split]
    requested = int(eval_cfg.get("baseline_num_eval_pairs", eval_cfg["num_eval_pairs"])) if args.limit is None else int(args.limit)
    num_eval_pairs = min(requested, split_data["source_points"].shape[0])
    max_landmarks = int(eval_cfg.get("baseline_max_landmarks", 32))
    output_dir = Path(eval_cfg["output_dir"]).parent / f"{Path(eval_cfg['output_dir']).name}_baseline"
    output_dir.mkdir(parents=True, exist_ok=True)
    baseline = LandmarkLDDMM(kernel_width=1.0, attachment_weight=25.0, n_steps=12, max_iter=25)

    rows = []
    predictions = []
    for index in range(num_eval_pairs):
        source = split_data["source_points"][index]
        target_padded = split_data["target_points"][index]
        target_valid = valid_target_points(target_padded)
        target_fit = target_valid
        source_fit = source[: target_fit.shape[0]]
        source_fit, target_fit = _subsample_pair(source_fit, target_fit, max_landmarks)
        start = time.perf_counter()
        fit = baseline.fit(source_fit, target_fit)
        pred = baseline.transform(source_fit, fit.source, fit.initial_momenta)
        runtime = record_runtime(start)
        jac_metrics = estimate_jacobian_metrics(
            lambda pts: baseline.transform(pts, fit.source, fit.initial_momenta),
            source_fit,
        )
        row = {
            "sample_index": index,
            "rmse": pointwise_rmse_if_possible(pred, target_fit),
            "chamfer": chamfer_distance(pred, target_fit),
            "hausdorff": hausdorff_distance(pred, target_fit),
            "runtime_sec": runtime,
            **jac_metrics,
        }
        rows.append(row)
        predictions.append(pred)
        print(f"baseline_progress={index + 1}/{num_eval_pairs} runtime_sec={runtime:.4f}", flush=True)

    metric_keys = ["rmse", "chamfer", "hausdorff", "runtime_sec", "jacobian_positive_rate", "jacobian_min_det", "fold_fraction"]
    summary = summarize_rows(rows, metric_keys)
    metrics_path, summary_path = save_eval_outputs(output_dir, rows, summary)
    if eval_cfg.get("save_figures", False):
        render_split_data = {
            "source_points": split_data["source_points"][: len(predictions)],
            "target_points": split_data["target_points"][: len(predictions)],
        }
        maybe_render_examples(rows, render_split_data, predictions, output_dir)

    print(f"split={split}")
    print(f"num_eval_pairs={num_eval_pairs}")
    print(f"metrics_csv={metrics_path}")
    print(f"summary_json={summary_path}")
    print(f"rmse_mean={summary['rmse_mean']}")
    print(f"chamfer_mean={summary['chamfer_mean']}")
    print(f"runtime_sec_mean={summary['runtime_sec_mean']}")


def _subsample_pair(source: np.ndarray, target: np.ndarray, max_landmarks: int):
    if source.shape[0] <= max_landmarks:
        return source, target
    indices = np.linspace(0, source.shape[0] - 1, max_landmarks, dtype=int)
    return source[indices], target[indices]


if __name__ == "__main__":
    main()
