from __future__ import annotations

import argparse
import time
from pathlib import Path

import numpy as np

from _eval_common import (
    ensure_bundle,
    estimate_jacobian_metrics,
    maybe_render_examples,
    pointwise_rmse_if_possible,
    record_runtime,
    save_eval_outputs,
    summarize_rows,
    valid_target_points,
)
from diffeo_sreps.metrics import chamfer_distance, hausdorff_distance
from diffeo_sreps.models.neural_ode import (
    MissingDeepDependencyError,
    NeuralODERegistrationModel,
)
from diffeo_sreps.render import save_markups_json
from diffeo_sreps.utils import load_yaml

try:
    import torch
except ImportError as exc:  # pragma: no cover
    torch = None
    _IMPORT_ERROR = exc
else:
    _IMPORT_ERROR = None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate the PointNet-conditioned Neural ODE model.")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--limit", type=int, default=None)
    return parser.parse_args()


def main() -> None:
    if torch is None:
        raise MissingDeepDependencyError(
            "Install the deep extra with `python -m pip install -e .[deep]`."
        ) from _IMPORT_ERROR

    args = parse_args()
    eval_cfg = load_yaml(args.config)
    _, bundle, _ = ensure_bundle(eval_cfg["data_config"])
    split = eval_cfg["split"]
    split_data = bundle[split]
    requested = int(eval_cfg["num_eval_pairs"]) if args.limit is None else int(args.limit)
    num_eval_pairs = min(requested, split_data["source_points"].shape[0])
    output_dir = Path(eval_cfg["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)

    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    train_cfg = checkpoint["config"]
    device = _select_device(args.device)
    model = NeuralODERegistrationModel(
        point_dim=3,
        latent_dim=int(train_cfg.get("latent_dim", 1024)),
        hidden_dim=int(train_cfg["hidden_dim"]),
        depth=int(train_cfg["depth"]),
        time_embedding=str(train_cfg.get("time_embedding", "scalar")),
        stationary=bool(train_cfg.get("stationary", False)),
    ).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    rows = []
    predictions = []
    for index in range(num_eval_pairs):
        source = split_data["source_points"][index].astype(np.float32)
        target_padded = split_data["target_points"][index].astype(np.float32)
        target_valid = valid_target_points(target_padded)
        target_input, target_mask = _target_tensor_pair(target_padded)
        start = time.perf_counter()
        pred = _predict(model, source, target_input, target_mask, train_cfg, device)
        runtime = record_runtime(start)
        jac_metrics = estimate_jacobian_metrics(
            lambda pts: _predict(model, pts.astype(np.float32), target_input, target_mask, train_cfg, device),
            source,
        )
        row = {
            "sample_index": index,
            "rmse": pointwise_rmse_if_possible(pred, target_padded),
            "chamfer": chamfer_distance(pred, target_valid),
            "hausdorff": hausdorff_distance(pred, target_valid),
            "runtime_sec": runtime,
            **jac_metrics,
        }
        rows.append(row)
        predictions.append(pred)

    metric_keys = ["rmse", "chamfer", "hausdorff", "runtime_sec", "jacobian_positive_rate", "jacobian_min_det", "fold_fraction"]
    summary = summarize_rows(rows, metric_keys)
    summary["checkpoint"] = args.checkpoint
    metrics_path, summary_path = save_eval_outputs(output_dir, rows, summary)
    if eval_cfg.get("save_figures", False):
        maybe_render_examples(rows, split_data, predictions, output_dir)
    _export_slicer_examples(split_data, predictions, output_dir)

    print(f"split={split}")
    print(f"num_eval_pairs={num_eval_pairs}")
    print(f"metrics_csv={metrics_path}")
    print(f"summary_json={summary_path}")
    print(f"rmse_mean={summary['rmse_mean']}")
    print(f"chamfer_mean={summary['chamfer_mean']}")
    print(f"runtime_sec_mean={summary['runtime_sec_mean']}")


def _target_tensor_pair(target_padded: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    mask = (~np.isnan(target_padded).any(axis=1)).astype(np.float32)
    target = np.where(mask[:, None] > 0.5, target_padded, 0.0).astype(np.float32)
    return target, mask


def _predict(model, source_points: np.ndarray, target_points: np.ndarray, target_mask: np.ndarray, train_cfg: dict, device) -> np.ndarray:
    with torch.no_grad():
        source_tensor = torch.from_numpy(source_points).unsqueeze(0).to(device)
        target_tensor = torch.from_numpy(target_points).unsqueeze(0).to(device)
        target_mask_tensor = torch.from_numpy(target_mask).unsqueeze(0).to(device)
        pred = model(
            source_tensor,
            target_tensor,
            target_mask=target_mask_tensor,
            n_steps=int(train_cfg["ode_steps"]),
            method=str(train_cfg["ode_method"]),
            return_trajectory=False,
        )
    return pred.squeeze(0).cpu().numpy()


def _select_device(requested: str):
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(requested)


def _export_slicer_examples(split_data: dict, predictions: list[np.ndarray], output_dir: Path) -> None:
    slicer_dir = Path("outputs/figures") / f"{output_dir.name}_slicer_markups"
    slicer_dir.mkdir(parents=True, exist_ok=True)
    for index in range(min(3, len(predictions))):
        source = split_data["source_points"][index]
        target = valid_target_points(split_data["target_points"][index])
        pred = predictions[index]
        save_markups_json(source, slicer_dir / f"sample_{index:02d}_source.mrk.json", name="source")
        save_markups_json(target, slicer_dir / f"sample_{index:02d}_target.mrk.json", name="target")
        save_markups_json(pred, slicer_dir / f"sample_{index:02d}_predicted.mrk.json", name="predicted")


if __name__ == "__main__":
    main()
