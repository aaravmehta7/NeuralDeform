from __future__ import annotations

import numpy as np

from diffeo_sreps.baselines import LandmarkLDDMM
from diffeo_sreps.geometry import make_ellipsoid_srep
from diffeo_sreps.metrics import landmark_rmse


def main() -> None:
    source = make_ellipsoid_srep(n_atoms=6, seed=3)
    target_atoms = source.atoms + 0.12 * np.column_stack(
        [
            np.sin(2.0 * source.atoms[:, 2]),
            np.cos(3.0 * source.atoms[:, 2]),
            np.zeros(source.atoms.shape[0]),
        ]
    )
    model = LandmarkLDDMM(kernel_width=0.75, attachment_weight=25.0, n_steps=12, max_iter=20)
    result = model.fit(source.atoms, target_atoms)
    print(f"success={result.success}")
    print(f"message={result.message}")
    print(f"atom_rmse={landmark_rmse(result.deformed_source, target_atoms):.6f}")


if __name__ == "__main__":
    main()
