from __future__ import annotations

import time

import numpy as np

from diffeo_sreps.baselines import LandmarkLDDMM, StationaryVelocityField, fit_affine, transform_affine
from diffeo_sreps.geometry import make_ellipsoid_srep
from diffeo_sreps.metrics import landmark_rmse


def make_target(atoms: np.ndarray) -> np.ndarray:
    warp = 0.12 * np.column_stack(
        [
            np.sin(2.0 * atoms[:, 2]),
            np.cos(3.0 * atoms[:, 2]),
            0.5 * np.sin(atoms[:, 0] + atoms[:, 1]),
        ]
    )
    return atoms + warp


def timed(name: str, fn):
    start = time.perf_counter()
    output = fn()
    elapsed = time.perf_counter() - start
    return name, output, elapsed


def main() -> None:
    source = make_ellipsoid_srep(n_atoms=6, seed=4)
    target_atoms = make_target(source.atoms)

    rows = []
    rows.append(
        timed(
            "affine",
            lambda: transform_affine(source.atoms, fit_affine(source.atoms, target_atoms)),
        )
    )

    mean_velocity = np.mean(target_atoms - source.atoms, axis=0)
    svf = StationaryVelocityField(lambda x: np.ones_like(x) * mean_velocity, n_steps=16)
    rows.append(timed("stationary_velocity_constant", lambda: svf.transform(source.atoms)))

    lddmm = LandmarkLDDMM(kernel_width=0.75, attachment_weight=25.0, n_steps=12, max_iter=20)
    rows.append(timed("landmark_lddmm", lambda: lddmm.fit(source.atoms, target_atoms).deformed_source))

    print("method,atom_rmse,seconds")
    for name, predicted, elapsed in rows:
        print(f"{name},{landmark_rmse(predicted, target_atoms):.6f},{elapsed:.4f}")


if __name__ == "__main__":
    main()
