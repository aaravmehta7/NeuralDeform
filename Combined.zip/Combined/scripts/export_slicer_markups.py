from __future__ import annotations

import argparse
from pathlib import Path

from _eval_common import ensure_bundle, valid_target_points
from diffeo_sreps.render import save_markups_json
from diffeo_sreps.utils import load_yaml


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Export source/target point sets to Slicer markups JSON.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--sample-index", type=int, default=0)
    parser.add_argument("--output-dir", default="outputs/figures/slicer_manual_export")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    eval_cfg = load_yaml(args.config)
    _, bundle, _ = ensure_bundle(eval_cfg["data_config"])
    split = eval_cfg["split"]
    split_data = bundle[split]
    index = min(max(args.sample_index, 0), split_data["source_points"].shape[0] - 1)
    output_dir = Path(args.output_dir)
    save_markups_json(split_data["source_points"][index], output_dir / "source.mrk.json", name="source")
    save_markups_json(valid_target_points(split_data["target_points"][index]), output_dir / "target.mrk.json", name="target")
    print(f"export_dir={output_dir}")
    print(f"split={split}")
    print(f"sample_index={index}")


if __name__ == "__main__":
    main()
