#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -lt 2 ]; then
  echo "Usage: $0 RUN_NAME COMMAND [ARGS...]" >&2
  exit 1
fi

RUN_NAME="$1"
shift

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LOG_DIR="$ROOT_DIR/outputs/logs"
PID_DIR="$ROOT_DIR/outputs/pids"
MPL_DIR="$ROOT_DIR/outputs/mplconfig"
mkdir -p "$LOG_DIR" "$PID_DIR" "$MPL_DIR"

STAMP="$(date +%Y%m%d_%H%M%S)"
LOG_PATH="$LOG_DIR/${RUN_NAME}_${STAMP}.log"
PID_PATH="$PID_DIR/${RUN_NAME}_${STAMP}.pid"
RUN_DURATION="${RUN_DURATION:-}"

if [ -n "$RUN_DURATION" ]; then
  setsid env MPLCONFIGDIR="$MPL_DIR" timeout "$RUN_DURATION" "$@" >"$LOG_PATH" 2>&1 < /dev/null &
else
  setsid env MPLCONFIGDIR="$MPL_DIR" "$@" >"$LOG_PATH" 2>&1 < /dev/null &
fi
PID="$!"
echo "$PID" > "$PID_PATH"

echo "run_name=$RUN_NAME"
echo "pid=$PID"
echo "log=$LOG_PATH"
echo "pid_file=$PID_PATH"
if [ -n "$RUN_DURATION" ]; then
  echo "duration=$RUN_DURATION"
fi
