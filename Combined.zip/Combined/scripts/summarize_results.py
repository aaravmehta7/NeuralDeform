from __future__ import annotations

import argparse
import json
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Summarize available JSON result files.")
    parser.add_argument("--results_dir", required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    root = Path(args.results_dir)
    summaries = sorted(root.rglob("summary.json"))
    print(f"num_summary_files={len(summaries)}")
    aggregate = []
    for summary_path in summaries:
        with summary_path.open("r", encoding="utf-8") as handle:
            payload = json.load(handle)
        print(f"{summary_path}: keys={sorted(payload.keys())}")
        aggregate.append({"path": str(summary_path), **payload})
    if aggregate:
        output_path = root / "tables" / "summary_index.json"
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with output_path.open("w", encoding="utf-8") as handle:
            json.dump(aggregate, handle, indent=2, sort_keys=True)
        print(f"summary_index={output_path}")


if __name__ == "__main__":
    main()
