#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -lt 2 ]; then
  echo "Usage: $0 TRAIN_CONFIG GPU_ARG" >&2
  exit 1
fi

TRAIN_CONFIG="$1"
GPU_ARG="$2"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python}"
DATA_CONFIG="$(awk -F': ' '/^data_config:/{print $2; exit}' "$TRAIN_CONFIG")"

cd "$ROOT_DIR"
export PYTHONPATH="$ROOT_DIR/src"
export PYTHONUNBUFFERED=1

log_stage() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] stage=$1 config=$TRAIN_CONFIG"
}

log_stage generate_data
"$PYTHON_BIN" scripts/generate_data.py --config "$DATA_CONFIG"
log_stage train
"$PYTHON_BIN" scripts/train.py --config "$TRAIN_CONFIG" --gpu "$GPU_ARG"
log_stage complete
