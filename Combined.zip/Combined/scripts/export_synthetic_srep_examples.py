from __future__ import annotations

import argparse
from pathlib import Path

from diffeo_sreps.data.synthetic_trajectory import make_synthetic_ellipsoid_to_object_trajectory
from diffeo_sreps.geometry import SinusoidalObjectFlow
from diffeo_sreps.render import save_markups_json


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Export synthetic s-rep examples to Slicer markups JSON.")
    parser.add_argument("--output-dir", default="outputs/figures/slicer_synthetic_examples")
    parser.add_argument("--num-examples", type=int, default=2)
    parser.add_argument("--n-atoms", type=int, default=24)
    return parser.parse_args()


def write_example(example_dir: Path, example_index: int, n_atoms: int) -> None:
    flow = SinusoidalObjectFlow(
        amplitude=0.12 + 0.03 * example_index,
        twist=0.28 + 0.05 * example_index,
        bend=0.08 + 0.02 * example_index,
    )
    trajectory = make_synthetic_ellipsoid_to_object_trajectory(
        n_atoms=n_atoms,
        n_stages=8,
        seed=example_index,
        flow=flow,
    )

    save_markups_json(
        trajectory.ellipsoid.atoms,
        example_dir / "ellipsoid_skeleton.mrk.json",
        name=f"example_{example_index:02d}_ellipsoid_skeleton",
        description="Synthetic source skeleton atoms",
    )
    save_markups_json(
        trajectory.ellipsoid.boundary_points,
        example_dir / "ellipsoid_boundary.mrk.json",
        name=f"example_{example_index:02d}_ellipsoid_boundary",
        description="Synthetic source boundary points",
    )
    save_markups_json(
        trajectory.target.atoms,
        example_dir / "target_skeleton.mrk.json",
        name=f"example_{example_index:02d}_target_skeleton",
        description="Synthetic deformed skeleton atoms",
    )
    save_markups_json(
        trajectory.target.boundary_points,
        example_dir / "target_boundary.mrk.json",
        name=f"example_{example_index:02d}_target_boundary",
        description="Synthetic deformed boundary points",
    )

    manifest = example_dir / "README.txt"
    manifest.write_text(
        "\n".join(
            [
                f"example_index={example_index}",
                f"n_atoms={n_atoms}",
                "Files:",
                "- ellipsoid_skeleton.mrk.json: source skeleton atoms",
                "- ellipsoid_boundary.mrk.json: source boundary points",
                "- target_skeleton.mrk.json: deformed skeleton atoms",
                "- target_boundary.mrk.json: deformed boundary points",
            ]
        )
        + "\n",
        encoding="utf-8",
    )


def main() -> None:
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    for example_index in range(max(args.num_examples, 1)):
        example_dir = output_dir / f"example_{example_index:02d}"
        example_dir.mkdir(parents=True, exist_ok=True)
        write_example(example_dir, example_index=example_index, n_atoms=args.n_atoms)
        print(f"exported_example={example_dir}")


if __name__ == "__main__":
    main()
