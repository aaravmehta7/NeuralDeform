#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python}"
LAUNCHER="$ROOT_DIR/scripts/launch_detached.sh"
export RUN_DURATION="${RUN_DURATION:-15h}"

"$LAUNCHER" main_gpu0 env CUDA_VISIBLE_DEVICES=0 PYTHONPATH="$ROOT_DIR/src" PYTHON_BIN="$PYTHON_BIN" "$ROOT_DIR/scripts/run_main_pipeline.sh" 0
"$LAUNCHER" no_fold_gpu1 env CUDA_VISIBLE_DEVICES=1 PYTHONPATH="$ROOT_DIR/src" PYTHON_BIN="$PYTHON_BIN" "$ROOT_DIR/scripts/run_ablation_pipeline.sh" "$ROOT_DIR/configs/train/ablation_no_fold.yaml" 0
"$LAUNCHER" no_smooth_gpu2 env CUDA_VISIBLE_DEVICES=2 PYTHONPATH="$ROOT_DIR/src" PYTHON_BIN="$PYTHON_BIN" "$ROOT_DIR/scripts/run_ablation_pipeline.sh" "$ROOT_DIR/configs/train/ablation_no_smooth.yaml" 0
"$LAUNCHER" traj_gpu3 env CUDA_VISIBLE_DEVICES=3 PYTHONPATH="$ROOT_DIR/src" PYTHON_BIN="$PYTHON_BIN" "$ROOT_DIR/scripts/run_ablation_pipeline.sh" "$ROOT_DIR/configs/train/ablation_traj.yaml" 0

echo "launched=4"
