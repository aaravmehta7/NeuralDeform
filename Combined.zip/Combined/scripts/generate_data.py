from __future__ import annotations

import argparse

from diffeo_sreps.data import generate_dataset_bundle, save_dataset_bundle
from diffeo_sreps.utils import load_yaml, seed_everything


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate synthetic proof-of-concept registration data.")
    parser.add_argument("--config", required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = load_yaml(args.config)
    seed_everything(int(config.get("seed", 0)))
    bundle = generate_dataset_bundle(config)
    output_path = save_dataset_bundle(bundle, config["output_path"])
    print(f"saved_dataset={output_path}")
    for split, split_data in bundle.items():
        print(f"{split}_size={split_data['source_points'].shape[0]}")


if __name__ == "__main__":
    main()
