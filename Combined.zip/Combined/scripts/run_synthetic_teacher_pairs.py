from __future__ import annotations

from diffeo_sreps.baselines import LandmarkLDDMM
from diffeo_sreps.metrics import (
    landmark_rmse,
    spoke_endpoint_rmse,
    spoke_near_intersection_count,
)
from diffeo_sreps.pipelines.synthetic import SyntheticEvolutionarySRepWrapper


def main() -> None:
    wrapper = SyntheticEvolutionarySRepWrapper(n_atoms=6, n_stages=6, seed=7)
    artifacts = wrapper.run(object_id="synthetic_smoke")
    print(f"object_id={artifacts.object_id}")
    print(f"n_stages={len(artifacts.cmcf_stages)}")
    print(f"n_teacher_pairs={len(artifacts.teacher_pairs)}")

    pair = artifacts.teacher_pairs[0]
    lddmm = LandmarkLDDMM(kernel_width=0.9, attachment_weight=25.0, n_steps=10, max_iter=15)
    fit = lddmm.fit(pair.source.boundary_points, pair.target.boundary_points)
    transported_atoms = lddmm.transform(pair.source.atoms, fit.source, fit.initial_momenta)
    transported_boundary = lddmm.transform(pair.source.boundary_points, fit.source, fit.initial_momenta)
    predicted_srep = pair.source.transported(transported_atoms, transported_boundary)

    print(f"pair_id={pair.pair_id}")
    print(f"teacher_boundary_rmse={landmark_rmse(fit.deformed_source, pair.target.boundary_points):.6f}")
    print(f"atom_rmse={landmark_rmse(predicted_srep.atoms, pair.target.atoms):.6f}")
    print(f"spoke_endpoint_rmse={spoke_endpoint_rmse(predicted_srep, pair.target):.6f}")
    print(f"spoke_near_intersections={spoke_near_intersection_count(predicted_srep)}")


if __name__ == "__main__":
    main()
