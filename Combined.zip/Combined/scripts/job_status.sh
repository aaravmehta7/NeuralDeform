#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PID_DIR="$ROOT_DIR/outputs/pids"

if [ ! -d "$PID_DIR" ]; then
  echo "No pid directory found."
  exit 0
fi

for pid_file in "$PID_DIR"/*.pid; do
  [ -e "$pid_file" ] || continue
  pid="$(cat "$pid_file")"
  if ps -p "$pid" >/dev/null 2>&1; then
    echo "$(basename "$pid_file"): running (pid=$pid)"
  else
    echo "$(basename "$pid_file"): finished_or_missing (pid=$pid)"
  fi
done
