from __future__ import annotations

import argparse

from diffeo_sreps.models.neural_ode import MissingDeepDependencyError
from diffeo_sreps.training import SyntheticNeuralODETrainConfig, train_synthetic_neural_ode


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train the presentation-aligned Neural ODE on synthetic data.")
    parser.add_argument("--data-config", default="configs/data/synthetic_presentation.yaml")
    parser.add_argument("--output-dir", default="outputs/checkpoints/presentation_experiment2_cli")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=32)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = SyntheticNeuralODETrainConfig(
        data_config_path=args.data_config,
        latent_dim=1024,
        hidden_dim=256,
        depth=4,
        ode_steps=12,
        ode_method="rk4",
        time_embedding="scalar",
        stationary=False,
        batch_size=args.batch_size,
        epochs=args.epochs,
        learning_rate=5e-4,
        weight_decay=1e-4,
        output_dir=args.output_dir,
        device=args.device,
        loss_weights={"point": 1.0, "traj": 0.5, "smooth": 0.01, "fold": 0.05, "inv": 0.0},
        early_stopping_patience=8,
        amp=True,
    )
    try:
        result = train_synthetic_neural_ode(config)
    except MissingDeepDependencyError as exc:
        raise SystemExit(str(exc)) from exc
    print(f"best_checkpoint={result.best_checkpoint}")
    print(f"final_train_loss={result.final_train_loss:.8e}")
    print(f"final_val_loss={result.final_val_loss:.8e}")
    print(f"device={result.device}")
    print(f"distributed={result.distributed}")


if __name__ == "__main__":
    main()
