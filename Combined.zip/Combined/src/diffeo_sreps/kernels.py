from __future__ import annotations

import numpy as np


def squared_distances(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    if x.ndim != 2 or y.ndim != 2:
        raise ValueError("x and y must be 2D arrays")
    if x.shape[1] != y.shape[1]:
        raise ValueError("x and y must have the same point dimension")
    diff = x[:, None, :] - y[None, :, :]
    return np.sum(diff * diff, axis=-1)


def gaussian_kernel(x: np.ndarray, y: np.ndarray, width: float) -> np.ndarray:
    if width <= 0:
        raise ValueError("width must be positive")
    return np.exp(-0.5 * squared_distances(x, y) / (width * width))
