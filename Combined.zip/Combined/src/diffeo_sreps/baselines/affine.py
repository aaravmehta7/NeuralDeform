from __future__ import annotations

import numpy as np


def fit_affine(source: np.ndarray, target: np.ndarray, ridge: float = 1e-8) -> np.ndarray:
    """Fit an affine transform from paired source to target landmarks.

    Returns a homogeneous matrix with shape `(dim + 1, dim + 1)`.
    """
    source = np.asarray(source, dtype=float)
    target = np.asarray(target, dtype=float)
    if source.shape != target.shape:
        raise ValueError("source and target must have the same shape")
    if source.ndim != 2:
        raise ValueError("source and target must be 2D arrays")

    ones = np.ones((source.shape[0], 1), dtype=float)
    design = np.concatenate([source, ones], axis=1)
    lhs = design.T @ design + ridge * np.eye(design.shape[1])
    rhs = design.T @ target
    coeff = np.linalg.solve(lhs, rhs)

    matrix = np.eye(source.shape[1] + 1, dtype=float)
    matrix[:-1, :] = coeff.T
    return matrix


def transform_affine(points: np.ndarray, matrix: np.ndarray) -> np.ndarray:
    """Apply a homogeneous affine matrix to points."""
    points = np.asarray(points, dtype=float)
    matrix = np.asarray(matrix, dtype=float)
    ones = np.ones((points.shape[0], 1), dtype=float)
    homogeneous = np.concatenate([points, ones], axis=1)
    return homogeneous @ matrix[:-1, :].T
