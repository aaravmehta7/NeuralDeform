"""Classical registration baselines."""

from diffeo_sreps.baselines.affine import fit_affine, transform_affine
from diffeo_sreps.baselines.lddmm import LandmarkLDDMM
from diffeo_sreps.baselines.svf import StationaryVelocityField

__all__ = [
    "LandmarkLDDMM",
    "StationaryVelocityField",
    "fit_affine",
    "transform_affine",
]
