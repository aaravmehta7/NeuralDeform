from __future__ import annotations

from dataclasses import dataclass
from types import SimpleNamespace

import numpy as np

from diffeo_sreps.kernels import gaussian_kernel

try:  # SciPy is useful, but the baseline remains runnable without it.
    from scipy.optimize import minimize as scipy_minimize
except ImportError:  # pragma: no cover - depends on the local environment
    scipy_minimize = None


@dataclass(frozen=True)
class LDDMMResult:
    source: np.ndarray
    target: np.ndarray
    initial_momenta: np.ndarray
    deformed_source: np.ndarray
    energy: float
    success: bool
    message: str


class LandmarkLDDMM:
    """Small-deformation-free LDDMM landmark shooting baseline.

    This implementation optimizes initial momenta with SciPy and integrates the
    landmark Hamiltonian forward in time. It is intentionally simple and useful
    as a correctness baseline for small to medium landmark/s-rep atom sets.
    """

    def __init__(
        self,
        kernel_width: float = 1.0,
        attachment_weight: float = 10.0,
        n_steps: int = 20,
        max_iter: int = 200,
    ) -> None:
        if kernel_width <= 0:
            raise ValueError("kernel_width must be positive")
        if attachment_weight <= 0:
            raise ValueError("attachment_weight must be positive")
        if n_steps <= 0:
            raise ValueError("n_steps must be positive")
        self.kernel_width = float(kernel_width)
        self.attachment_weight = float(attachment_weight)
        self.n_steps = int(n_steps)
        self.max_iter = int(max_iter)

    def fit(self, source: np.ndarray, target: np.ndarray) -> LDDMMResult:
        source = np.asarray(source, dtype=float)
        target = np.asarray(target, dtype=float)
        self._validate_pair(source, target)

        def objective(flat_momenta: np.ndarray) -> float:
            momenta = flat_momenta.reshape(source.shape)
            deformed, _ = self._integrate_landmarks(source, momenta)
            data = 0.5 * self.attachment_weight * np.sum((deformed - target) ** 2)
            reg = self._hamiltonian(source, momenta)
            return float(reg + data)

        opt = self._minimize(objective, np.zeros_like(source).ravel())
        momenta = opt.x.reshape(source.shape)
        deformed, _ = self._integrate_landmarks(source, momenta)
        return LDDMMResult(
            source=source,
            target=target,
            initial_momenta=momenta,
            deformed_source=deformed,
            energy=float(opt.fun),
            success=bool(opt.success),
            message=str(opt.message),
        )

    def transform(
        self,
        points: np.ndarray,
        control_points: np.ndarray,
        initial_momenta: np.ndarray,
    ) -> np.ndarray:
        """Transport arbitrary points through the learned landmark flow."""
        points = np.asarray(points, dtype=float)
        control_points = np.asarray(control_points, dtype=float)
        initial_momenta = np.asarray(initial_momenta, dtype=float)
        q = control_points.copy()
        p = initial_momenta.copy()
        x = points.copy()
        dt = 1.0 / self.n_steps

        for _ in range(self.n_steps):
            x = x + dt * self._velocity(x, q, p)
            q, p = self._rk4_landmark_step(q, p, dt)
        return x

    def _integrate_landmarks(
        self, control_points: np.ndarray, initial_momenta: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray]:
        q = control_points.copy()
        p = initial_momenta.copy()
        dt = 1.0 / self.n_steps
        for _ in range(self.n_steps):
            q, p = self._rk4_landmark_step(q, p, dt)
        return q, p

    def _rk4_landmark_step(self, q: np.ndarray, p: np.ndarray, dt: float) -> tuple[np.ndarray, np.ndarray]:
        k1q, k1p = self._landmark_rhs(q, p)
        k2q, k2p = self._landmark_rhs(q + 0.5 * dt * k1q, p + 0.5 * dt * k1p)
        k3q, k3p = self._landmark_rhs(q + 0.5 * dt * k2q, p + 0.5 * dt * k2p)
        k4q, k4p = self._landmark_rhs(q + dt * k3q, p + dt * k3p)
        q_next = q + (dt / 6.0) * (k1q + 2.0 * k2q + 2.0 * k3q + k4q)
        p_next = p + (dt / 6.0) * (k1p + 2.0 * k2p + 2.0 * k3p + k4p)
        return q_next, p_next

    def _landmark_rhs(self, q: np.ndarray, p: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        k = gaussian_kernel(q, q, self.kernel_width)
        dq = k @ p
        dot = p @ p.T
        diff = q[:, None, :] - q[None, :, :]
        weighted = dot[:, :, None] * k[:, :, None] * diff / (self.kernel_width**2)
        dp = np.sum(weighted, axis=1)
        return dq, dp

    def _velocity(self, points: np.ndarray, control_points: np.ndarray, momenta: np.ndarray) -> np.ndarray:
        return gaussian_kernel(points, control_points, self.kernel_width) @ momenta

    def _hamiltonian(self, q: np.ndarray, p: np.ndarray) -> float:
        k = gaussian_kernel(q, q, self.kernel_width)
        return 0.5 * float(np.sum((k @ p) * p))

    def _minimize(self, objective, x0: np.ndarray):
        if scipy_minimize is not None:
            return scipy_minimize(
                objective,
                x0,
                method="L-BFGS-B",
                options={"maxiter": self.max_iter, "ftol": 1e-9},
            )
        return self._finite_difference_descent(objective, x0)

    def _finite_difference_descent(self, objective, x0: np.ndarray):
        """Small fallback optimizer for environments without SciPy.

        This is deliberately conservative and intended for smoke tests and tiny
        landmark sets. Install the `optim` extra for real experiments.
        """
        x = x0.astype(float).copy()
        best = objective(x)
        step = 0.2
        eps = 1e-4
        message = "finite-difference descent reached max_iter"

        for _ in range(self.max_iter):
            grad = np.zeros_like(x)
            for idx in range(x.size):
                old = x[idx]
                x[idx] = old + eps
                f_plus = objective(x)
                x[idx] = old - eps
                f_minus = objective(x)
                x[idx] = old
                grad[idx] = (f_plus - f_minus) / (2.0 * eps)

            grad_norm = float(np.linalg.norm(grad))
            if grad_norm < 1e-6:
                message = "finite-difference descent converged"
                break

            accepted = False
            direction = grad / max(grad_norm, 1e-12)
            for _ in range(8):
                candidate = x - step * direction
                value = objective(candidate)
                if value < best:
                    x = candidate
                    best = value
                    step = min(step * 1.2, 1.0)
                    accepted = True
                    break
                step *= 0.5
            if not accepted and step < 1e-8:
                message = "finite-difference descent stalled"
                break

        return SimpleNamespace(x=x, fun=best, success=True, message=message)

    @staticmethod
    def _validate_pair(source: np.ndarray, target: np.ndarray) -> None:
        if source.shape != target.shape:
            raise ValueError("source and target must have the same shape")
        if source.ndim != 2:
            raise ValueError("source and target must be 2D arrays")
        if source.shape[0] < 2:
            raise ValueError("at least two landmarks are required")
