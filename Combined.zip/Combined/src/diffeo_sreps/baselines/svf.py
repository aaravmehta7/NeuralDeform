from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np


VelocityFn = Callable[[np.ndarray], np.ndarray]


@dataclass
class StationaryVelocityField:
    """Integrate a stationary velocity field with explicit Euler steps."""

    velocity: VelocityFn
    n_steps: int = 32

    def transform(self, points: np.ndarray, time: float = 1.0) -> np.ndarray:
        if self.n_steps <= 0:
            raise ValueError("n_steps must be positive")
        points = np.asarray(points, dtype=float)
        x = points.copy()
        dt = float(time) / self.n_steps
        for _ in range(self.n_steps):
            x = x + dt * np.asarray(self.velocity(x), dtype=float)
        return x

    def inverse(self, points: np.ndarray, time: float = 1.0) -> np.ndarray:
        return StationaryVelocityField(lambda x: -self.velocity(x), self.n_steps).transform(points, time)
