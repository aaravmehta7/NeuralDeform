from __future__ import annotations

import numpy as np

from diffeo_sreps.geometry.srep import SRep


def landmark_rmse(predicted: np.ndarray, target: np.ndarray) -> float:
    predicted = np.asarray(predicted, dtype=float)
    target = np.asarray(target, dtype=float)
    if predicted.shape != target.shape:
        raise ValueError("predicted and target must have matching shapes")
    return float(np.sqrt(np.mean(np.sum((predicted - target) ** 2, axis=-1))))


def chamfer_distance(predicted: np.ndarray, target: np.ndarray) -> float:
    predicted = np.asarray(predicted, dtype=float)
    target = np.asarray(target, dtype=float)
    dist = np.sum((predicted[:, None, :] - target[None, :, :]) ** 2, axis=-1)
    return float(np.mean(np.min(dist, axis=1)) + np.mean(np.min(dist, axis=0)))


def hausdorff_distance(predicted: np.ndarray, target: np.ndarray) -> float:
    predicted = np.asarray(predicted, dtype=float)
    target = np.asarray(target, dtype=float)
    dist = np.sqrt(np.sum((predicted[:, None, :] - target[None, :, :]) ** 2, axis=-1))
    return float(max(np.max(np.min(dist, axis=1)), np.max(np.min(dist, axis=0))))


def relative_spoke_error(predicted: SRep, target: SRep, eps: float = 1e-8) -> float:
    if predicted.spokes.shape != target.spokes.shape:
        raise ValueError("s-reps must have matching spoke shapes")
    numerator = np.linalg.norm(predicted.spokes - target.spokes)
    denominator = np.linalg.norm(target.spokes) + eps
    return float(numerator / denominator)


def spoke_endpoint_rmse(predicted: SRep, target: SRep) -> float:
    """RMSE between implied boundary samples at spoke endpoints."""
    return landmark_rmse(predicted.boundary_points, target.boundary_points)


def spoke_direction_error_degrees(predicted: SRep, target: SRep, eps: float = 1e-8) -> float:
    """Mean angular spoke-direction error in degrees."""
    if predicted.spokes.shape != target.spokes.shape:
        raise ValueError("s-reps must have matching spoke shapes")
    pred = predicted.spokes.reshape(-1, predicted.spokes.shape[-1])
    true = target.spokes.reshape(-1, target.spokes.shape[-1])
    pred_norm = pred / (np.linalg.norm(pred, axis=-1, keepdims=True) + eps)
    true_norm = true / (np.linalg.norm(true, axis=-1, keepdims=True) + eps)
    cosines = np.sum(pred_norm * true_norm, axis=-1)
    angles = np.degrees(np.arccos(np.clip(cosines, -1.0, 1.0)))
    return float(np.mean(angles))


def inverse_consistency_error(
    points: np.ndarray,
    forward_points: np.ndarray,
    recovered_points: np.ndarray,
) -> float:
    """RMSE after applying a forward map and then its learned/numerical inverse."""
    points = np.asarray(points, dtype=float)
    forward_points = np.asarray(forward_points, dtype=float)
    recovered_points = np.asarray(recovered_points, dtype=float)
    if points.shape != forward_points.shape or points.shape != recovered_points.shape:
        raise ValueError("all point arrays must have matching shapes")
    return landmark_rmse(recovered_points, points)


def spoke_near_intersection_count(srep: SRep, threshold: float = 1e-3) -> int:
    """Count non-shared spoke segment pairs closer than `threshold`.

    In 3D, exact segment intersections are rare under floating-point arithmetic,
    so this metric treats very small segment-to-segment distances as practical
    near-intersections.
    """
    distances = _non_shared_spoke_distances(srep)
    return int(np.sum(distances < threshold))


def spoke_near_intersection_min_distance(srep: SRep) -> float:
    """Minimum distance between non-shared spoke segments."""
    distances = _non_shared_spoke_distances(srep)
    if distances.size == 0:
        return float("inf")
    return float(np.min(distances))


def _non_shared_spoke_distances(srep: SRep) -> np.ndarray:
    starts, ends, atom_ids = _spoke_segments(srep)
    distances = []
    for i in range(starts.shape[0]):
        for j in range(i + 1, starts.shape[0]):
            if atom_ids[i] == atom_ids[j]:
                continue
            distances.append(_segment_distance(starts[i], ends[i], starts[j], ends[j]))
    return np.asarray(distances, dtype=float)


def _spoke_segments(srep: SRep) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    n_atoms, n_spokes, dim = srep.spokes.shape
    starts = np.repeat(srep.atoms[:, None, :], n_spokes, axis=1).reshape(-1, dim)
    ends = starts + srep.spokes.reshape(-1, dim)
    atom_ids = np.repeat(np.arange(n_atoms), n_spokes)
    return starts, ends, atom_ids


def _segment_distance(p1: np.ndarray, q1: np.ndarray, p2: np.ndarray, q2: np.ndarray) -> float:
    """Shortest distance between two 3D line segments."""
    d1 = q1 - p1
    d2 = q2 - p2
    r = p1 - p2
    a = float(np.dot(d1, d1))
    e = float(np.dot(d2, d2))
    f = float(np.dot(d2, r))
    eps = 1e-12

    if a <= eps and e <= eps:
        return float(np.linalg.norm(p1 - p2))
    if a <= eps:
        s = 0.0
        t = np.clip(f / e, 0.0, 1.0)
    else:
        c = float(np.dot(d1, r))
        if e <= eps:
            t = 0.0
            s = np.clip(-c / a, 0.0, 1.0)
        else:
            b = float(np.dot(d1, d2))
            denom = a * e - b * b
            if denom != 0.0:
                s = np.clip((b * f - c * e) / denom, 0.0, 1.0)
            else:
                s = 0.0
            t = (b * s + f) / e
            if t < 0.0:
                t = 0.0
                s = np.clip(-c / a, 0.0, 1.0)
            elif t > 1.0:
                t = 1.0
                s = np.clip((b - c) / a, 0.0, 1.0)

    closest_1 = p1 + s * d1
    closest_2 = p2 + t * d2
    return float(np.linalg.norm(closest_1 - closest_2))
