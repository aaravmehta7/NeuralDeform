"""Dataset loaders and manifests."""

from diffeo_sreps.data.synthetic_trajectory import (
    SyntheticTrajectory,
    TeacherPair,
    make_synthetic_ellipsoid_to_object_trajectory,
    make_teacher_pairs,
)
from diffeo_sreps.data.proof_of_concept import (
    build_sample,
    generate_dataset_bundle,
    generate_smooth_flow_field,
    save_dataset_bundle,
)
from diffeo_sreps.data.torch_dataset import (
    SyntheticRegistrationDataset,
    TeacherPairDataset,
    bundle_split_to_arrays,
    teacher_pair_to_arrays,
)

__all__ = [
    "SyntheticTrajectory",
    "SyntheticRegistrationDataset",
    "TeacherPairDataset",
    "TeacherPair",
    "build_sample",
    "bundle_split_to_arrays",
    "generate_dataset_bundle",
    "generate_smooth_flow_field",
    "make_synthetic_ellipsoid_to_object_trajectory",
    "make_teacher_pairs",
    "save_dataset_bundle",
    "teacher_pair_to_arrays",
]
