from __future__ import annotations

import numpy as np

from diffeo_sreps.data.synthetic_trajectory import TeacherPair
from diffeo_sreps.models.neural_ode import MissingDeepDependencyError

try:
    import torch
    from torch.utils.data import Dataset
except ImportError as exc:  # pragma: no cover - depends on local environment
    torch = None
    Dataset = object
    _IMPORT_ERROR = exc
else:
    _IMPORT_ERROR = None


def teacher_pair_to_arrays(pair: TeacherPair) -> dict[str, np.ndarray]:
    """Convert a teacher pair into point arrays and a compact condition vector."""
    source_points = np.concatenate([pair.source.atoms, pair.source.boundary_points], axis=0)
    target_points = np.concatenate([pair.target.atoms, pair.target.boundary_points], axis=0)
    source_center = np.mean(source_points, axis=0)
    target_center = np.mean(target_points, axis=0)
    condition = np.concatenate(
        [
            np.asarray([pair.source_time, pair.target_time], dtype=float),
            source_center,
            target_center - source_center,
        ]
    )
    return {
        "source_points": source_points.astype("float32"),
        "target_points": target_points.astype("float32"),
        "condition": condition.astype("float32"),
    }


def bundle_split_to_arrays(split_data: dict[str, np.ndarray]) -> dict[str, np.ndarray]:
    source_points = np.asarray(split_data["source_points"], dtype=np.float32)
    target_points = np.asarray(split_data["target_points"], dtype=np.float32)
    traj_gt = np.asarray(split_data["traj_gt"], dtype=np.float32)
    target_mask = ~np.isnan(target_points).any(axis=-1)
    target_filled = np.where(target_mask[..., None], target_points, 0.0).astype(np.float32)
    return {
        "source_points": source_points,
        "target_points": target_filled,
        "target_mask": target_mask.astype(np.float32),
        "traj_gt": traj_gt,
        "deformation_strength": np.asarray(split_data.get("deformation_strength", np.zeros(source_points.shape[0])), dtype=np.float32),
        "noise_level": np.asarray(split_data.get("noise_level", np.zeros(source_points.shape[0])), dtype=np.float32),
    }


if torch is not None:

    class TeacherPairDataset(Dataset):
        """Torch dataset over synthetic or pipeline-generated adjacent teacher maps."""

        def __init__(self, pairs: list[TeacherPair]) -> None:
            if not pairs:
                raise ValueError("pairs must be non-empty")
            self.pairs = pairs

        def __len__(self) -> int:
            return len(self.pairs)

        def __getitem__(self, index: int) -> dict[str, torch.Tensor | str]:
            pair = self.pairs[index]
            arrays = teacher_pair_to_arrays(pair)
            return {
                "source_points": torch.from_numpy(arrays["source_points"]),
                "target_points": torch.from_numpy(arrays["target_points"]),
                "condition": torch.from_numpy(arrays["condition"]),
                "pair_id": pair.pair_id,
            }


    class SyntheticRegistrationDataset(Dataset):
        """Dataset for source-target skeletal point clouds and full deformation trajectories."""

        def __init__(self, split_data: dict[str, np.ndarray]) -> None:
            arrays = bundle_split_to_arrays(split_data)
            self.source_points = arrays["source_points"]
            self.target_points = arrays["target_points"]
            self.target_mask = arrays["target_mask"]
            self.traj_gt = arrays["traj_gt"]
            self.deformation_strength = arrays["deformation_strength"]
            self.noise_level = arrays["noise_level"]
            if self.source_points.shape[0] == 0:
                raise ValueError("split_data must contain at least one sample")

        def __len__(self) -> int:
            return int(self.source_points.shape[0])

        def __getitem__(self, index: int) -> dict[str, torch.Tensor]:
            return {
                "source_points": torch.from_numpy(self.source_points[index]),
                "target_points": torch.from_numpy(self.target_points[index]),
                "target_mask": torch.from_numpy(self.target_mask[index]),
                "traj_gt": torch.from_numpy(self.traj_gt[index]),
                "deformation_strength": torch.as_tensor(self.deformation_strength[index]),
                "noise_level": torch.as_tensor(self.noise_level[index]),
            }

else:

    class TeacherPairDataset:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs) -> None:
            raise MissingDeepDependencyError(
                "Install the deep extra with `python -m pip install -e .[deep]`."
            ) from _IMPORT_ERROR


    class SyntheticRegistrationDataset:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs) -> None:
            raise MissingDeepDependencyError(
                "Install the deep extra with `python -m pip install -e .[deep]`."
            ) from _IMPORT_ERROR
