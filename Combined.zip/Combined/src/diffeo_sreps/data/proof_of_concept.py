from __future__ import annotations

from pathlib import Path

import numpy as np

from diffeo_sreps.geometry.templates import generate_template


def generate_smooth_flow_field(
    seed: int,
    num_centers: int,
    sigma_range: tuple[float, float],
    amplitude_range: tuple[float, float],
    time_dependent: bool,
):
    rng = np.random.default_rng(seed)
    centers = rng.uniform(-0.8, 0.8, size=(num_centers, 3))
    sigmas = rng.uniform(sigma_range[0], sigma_range[1], size=(num_centers,))
    amplitudes = rng.uniform(amplitude_range[0], amplitude_range[1], size=(num_centers, 3))
    phases = rng.uniform(0.0, 2.0 * np.pi, size=(num_centers,))

    def velocity(points, t):
        points = np.asarray(points, dtype=float)
        t_val = float(np.asarray(t).reshape(-1)[0]) if np.asarray(t).size else float(t)
        diff = points[:, None, :] - centers[None, :, :]
        sq_norm = np.sum(diff * diff, axis=-1)
        weights = np.exp(-sq_norm / np.clip(sigmas[None, :] ** 2, 1e-8, None))
        if time_dependent:
            time_scale = 0.5 + 0.5 * np.sin(2.0 * np.pi * t_val + phases)
        else:
            time_scale = np.ones_like(phases)
        return np.sum(weights[:, :, None] * amplitudes[None, :, :] * time_scale[None, :, None], axis=1)

    return velocity


def integrate_flow(points: np.ndarray, velocity_fn, n_steps: int, strength: float) -> np.ndarray:
    x = np.asarray(points, dtype=float).copy()
    dt = 1.0 / n_steps
    for step in range(n_steps):
        t = step * dt
        k1 = velocity_fn(x, t)
        k2 = velocity_fn(x + 0.5 * dt * k1, t + 0.5 * dt)
        k3 = velocity_fn(x + 0.5 * dt * k2, t + 0.5 * dt)
        k4 = velocity_fn(x + dt * k3, t + dt)
        x = x + strength * (dt / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)
    return x


def build_sample(
    template_type: str,
    num_points: int,
    num_time_steps: int,
    strength: float,
    noise_std: float,
    dropout_fraction: float,
    seed: int,
    num_centers: int = 5,
    sigma_range: tuple[float, float] = (0.3, 0.8),
    amplitude_range: tuple[float, float] = (-0.18, 0.18),
    time_dependent: bool = True,
) -> dict:
    template = generate_template(template_type, num_points=num_points, seed=seed)
    flow = generate_smooth_flow_field(
        seed=seed + 13,
        num_centers=num_centers,
        sigma_range=sigma_range,
        amplitude_range=amplitude_range,
        time_dependent=time_dependent,
    )
    traj = [template["points"]]
    for step in range(1, num_time_steps + 1):
        traj.append(integrate_flow(template["points"], flow, n_steps=step, strength=strength * step / num_time_steps))
    traj = np.stack(traj, axis=0)
    source_points = traj[0]
    target_points = traj[-1]
    if noise_std > 0.0:
        target_points = target_points + noise_std * np.random.default_rng(seed + 101).normal(size=target_points.shape)
    if dropout_fraction > 0.0:
        keep = np.random.default_rng(seed + 202).random(target_points.shape[0]) > dropout_fraction
        if np.any(keep):
            target_points = target_points[keep]
    return {
        "source_points": source_points.astype(np.float32),
        "target_points": target_points.astype(np.float32),
        "traj_gt": traj.astype(np.float32),
        "template_type": template_type,
        "deformation_strength": float(strength),
        "flow_params": {
            "num_centers": int(num_centers),
            "time_dependent": bool(time_dependent),
            "sigma_range": tuple(float(v) for v in sigma_range),
            "amplitude_range": tuple(float(v) for v in amplitude_range),
        },
        "noise_level": float(noise_std),
    }


def generate_dataset_bundle(config: dict) -> dict[str, dict[str, np.ndarray]]:
    seed = int(config.get("seed", 0))
    num_points = int(config["num_points"])
    num_time_steps = int(config["num_time_steps"])
    template_types = list(config["template_types"])
    ood_template_types = list(config.get("ood_template_types", []))
    deformation_strength = config["deformation_strength"]
    noise_std = config["noise_std"]
    dropout_fraction = config["dropout_fraction"]
    num_flow_centers = int(config.get("num_flow_centers", 5))
    sigma_range = tuple(config.get("sigma_range", (0.3, 0.8)))
    amplitude_range = tuple(config.get("amplitude_range", (-0.18, 0.18)))
    time_dependent = bool(config.get("time_dependent", True))

    split_specs = {
        "train": (int(config["train_size"]), template_types, tuple(deformation_strength["train"])),
        "val": (int(config["val_size"]), template_types, tuple(deformation_strength.get("val", deformation_strength["train"]))),
        "test_in_domain": (int(config["test_in_domain_size"]), template_types, tuple(deformation_strength["test_in_domain"])),
        "test_ood_strong": (int(config["test_ood_strong_size"]), template_types, tuple(deformation_strength["test_ood_strong"])),
        "test_ood_shape": (int(config["test_ood_shape_size"]), ood_template_types or template_types, tuple(deformation_strength["test_in_domain"])),
        "test_ood_noise": (int(config["test_ood_noise_size"]), template_types, tuple(deformation_strength["test_in_domain"])),
    }

    bundle = {}
    for split_index, (split, (size, families, strength_range)) in enumerate(split_specs.items()):
        sources = []
        targets = []
        trajectories = []
        types = []
        strengths = []
        noises = []
        for sample_index in range(size):
            family = families[sample_index % len(families)]
            strength = np.random.default_rng(seed + 1000 * split_index + sample_index).uniform(*strength_range)
            sample = build_sample(
                template_type=family,
                num_points=num_points,
                num_time_steps=num_time_steps,
                strength=strength,
                noise_std=float(noise_std.get(split, 0.0)),
                dropout_fraction=float(dropout_fraction.get(split, 0.0)),
                seed=seed + 100000 * split_index + sample_index,
                num_centers=num_flow_centers,
                sigma_range=sigma_range,
                amplitude_range=amplitude_range,
                time_dependent=time_dependent,
            )
            sources.append(sample["source_points"])
            full_target = sample["traj_gt"][-1]
            padded_target = np.full_like(full_target, np.nan)
            padded_target[: sample["target_points"].shape[0]] = sample["target_points"]
            targets.append(padded_target)
            trajectories.append(sample["traj_gt"])
            types.append(sample["template_type"])
            strengths.append(sample["deformation_strength"])
            noises.append(sample["noise_level"])
        bundle[split] = {
            "source_points": np.stack(sources, axis=0),
            "target_points": np.stack(targets, axis=0),
            "traj_gt": np.stack(trajectories, axis=0),
            "template_type": np.asarray(types),
            "deformation_strength": np.asarray(strengths, dtype=np.float32),
            "noise_level": np.asarray(noises, dtype=np.float32),
        }
    return bundle


def save_dataset_bundle(bundle: dict[str, dict[str, np.ndarray]], output_path: str | Path) -> Path:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    flat = {}
    for split, split_data in bundle.items():
        for key, value in split_data.items():
            flat[f"{split}__{key}"] = value
    np.savez_compressed(output_path, **flat)
    return output_path
