from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from diffeo_sreps.geometry.flows import SinusoidalObjectFlow, interpolate_stage_points
from diffeo_sreps.geometry.srep import SRep
from diffeo_sreps.geometry.synthetic import make_ellipsoid_srep


@dataclass(frozen=True)
class SyntheticTrajectory:
    """Ellipsoid-to-object trajectory with s-reps at each stage."""

    ellipsoid: SRep
    target: SRep
    stages: tuple[SRep, ...]
    stage_times: np.ndarray

    @property
    def backward_pairs(self) -> tuple[tuple[SRep, SRep], ...]:
        """Pairs ordered like CMCF backward flow: smoother stage -> less smooth stage."""
        return tuple((self.stages[i + 1], self.stages[i]) for i in range(len(self.stages) - 1))


@dataclass(frozen=True)
class TeacherPair:
    source: SRep
    target: SRep
    source_time: float
    target_time: float
    object_id: str
    pair_id: str


def make_synthetic_ellipsoid_to_object_trajectory(
    n_atoms: int = 8,
    n_stages: int = 8,
    seed: int = 0,
    flow: SinusoidalObjectFlow | None = None,
) -> SyntheticTrajectory:
    """Build a synthetic trajectory from analytic ellipsoid s-rep to deformed target s-rep."""
    if n_stages < 2:
        raise ValueError("n_stages must be at least two")
    ellipsoid = make_ellipsoid_srep(n_atoms=n_atoms, seed=seed)
    flow = flow or SinusoidalObjectFlow()

    target_atoms = flow.transform(ellipsoid.atoms)
    target_boundary = flow.transform(ellipsoid.boundary_points)
    target = ellipsoid.transported(target_atoms, target_boundary)

    stage_times = np.linspace(0.0, 1.0, n_stages)
    stages: list[SRep] = []
    for alpha in stage_times:
        atoms = interpolate_stage_points(ellipsoid.atoms, target.atoms, float(alpha))
        boundary = interpolate_stage_points(ellipsoid.boundary_points, target.boundary_points, float(alpha))
        stages.append(ellipsoid.transported(atoms, boundary))

    return SyntheticTrajectory(
        ellipsoid=ellipsoid,
        target=target,
        stages=tuple(stages),
        stage_times=stage_times,
    )


def make_teacher_pairs(
    n_objects: int = 4,
    n_atoms: int = 8,
    n_stages: int = 8,
    seed: int = 0,
) -> list[TeacherPair]:
    """Create adjacent synthetic backward-flow pairs for supervised training."""
    pairs: list[TeacherPair] = []
    for object_index in range(n_objects):
        object_seed = seed + object_index
        flow = SinusoidalObjectFlow(
            amplitude=0.12 + 0.02 * (object_index % 4),
            twist=0.30 + 0.04 * (object_index % 5),
            bend=0.08 + 0.015 * (object_index % 3),
        )
        trajectory = make_synthetic_ellipsoid_to_object_trajectory(
            n_atoms=n_atoms,
            n_stages=n_stages,
            seed=object_seed,
            flow=flow,
        )
        for pair_index, (source, target) in enumerate(trajectory.backward_pairs):
            pairs.append(
                TeacherPair(
                    source=source,
                    target=target,
                    source_time=float(trajectory.stage_times[pair_index + 1]),
                    target_time=float(trajectory.stage_times[pair_index]),
                    object_id=f"synthetic_{object_index:04d}",
                    pair_id=f"synthetic_{object_index:04d}_stage_{pair_index + 1:02d}_to_{pair_index:02d}",
                )
            )
    return pairs
