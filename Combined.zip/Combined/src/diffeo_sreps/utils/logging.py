from __future__ import annotations

import csv
import json
from pathlib import Path


class RunLogger:
    """Minimal logger that writes console, CSV, and JSON artifacts."""

    def __init__(self, run_dir: str | Path) -> None:
        self.run_dir = Path(run_dir)
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self.csv_path = self.run_dir / "metrics.csv"
        self.json_path = self.run_dir / "summary.json"
        self._csv_header_written = self.csv_path.exists() and self.csv_path.stat().st_size > 0

    def log(self, **metrics) -> None:
        print(" ".join(f"{key}={value}" for key, value in metrics.items()), flush=True)
        with self.csv_path.open("a", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(metrics.keys()))
            if not self._csv_header_written:
                writer.writeheader()
                self._csv_header_written = True
            writer.writerow(metrics)

    def write_summary(self, summary: dict) -> None:
        with self.json_path.open("w", encoding="utf-8") as handle:
            json.dump(summary, handle, indent=2, sort_keys=True)
