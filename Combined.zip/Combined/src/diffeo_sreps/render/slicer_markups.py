from __future__ import annotations

import json
from pathlib import Path

import numpy as np


MARKUPS_SCHEMA = (
    "https://raw.githubusercontent.com/Slicer/Slicer/main/Modules/Loadable/Markups/Resources/Schema/"
    "markups-schema-v1.0.0.json#"
)


def points_to_slicer_markups(points: np.ndarray, name: str, description: str = "") -> dict:
    points = np.asarray(points, dtype=float)
    control_points = []
    for index, point in enumerate(points):
        control_points.append(
            {
                "id": str(index + 1),
                "label": f"{name}-{index + 1}",
                "description": description,
                "position": [float(point[0]), float(point[1]), float(point[2])],
                "selected": True,
                "locked": False,
                "visibility": True,
            }
        )
    return {
        "@schema": MARKUPS_SCHEMA,
        "markups": [
            {
                "type": "Fiducial",
                "coordinateSystem": "LPS",
                "locked": False,
                "labelFormat": f"{name}-%d",
                "controlPoints": control_points,
                "display": {
                    "visibility": True,
                    "propertiesLabelVisibility": True,
                },
            }
        ],
    }


def save_markups_json(points: np.ndarray, output_path: str | Path, name: str, description: str = "") -> Path:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    payload = points_to_slicer_markups(points, name=name, description=description)
    with output_path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
    return output_path
