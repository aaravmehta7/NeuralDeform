"""Simple rendering utilities."""

from diffeo_sreps.render.simple import render_registration
from diffeo_sreps.render.slicer_markups import save_markups_json

__all__ = ["render_registration", "save_markups_json"]
