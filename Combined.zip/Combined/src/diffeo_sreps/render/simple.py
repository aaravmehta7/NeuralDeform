from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def render_registration(source, target, pred=None, baseline=None, save_path=None):
    source = np.asarray(source)
    target = np.asarray(target)
    fig = plt.figure(figsize=(6, 6))
    ax = fig.add_subplot(111, projection="3d")
    ax.scatter(source[:, 0], source[:, 1], source[:, 2], s=8, label="source")
    ax.scatter(target[:, 0], target[:, 1], target[:, 2], s=8, label="target")
    if pred is not None:
        pred = np.asarray(pred)
        ax.scatter(pred[:, 0], pred[:, 1], pred[:, 2], s=8, label="pred")
    if baseline is not None:
        baseline = np.asarray(baseline)
        ax.scatter(baseline[:, 0], baseline[:, 1], baseline[:, 2], s=8, label="baseline")
    ax.legend(loc="upper right")
    if save_path is not None:
        save_path = Path(save_path)
        save_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=180, bbox_inches="tight")
    plt.close(fig)
