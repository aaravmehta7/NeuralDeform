from __future__ import annotations

import numpy as np


def generate_template(template_type: str, num_points: int, seed: int) -> dict:
    if num_points < 8:
        raise ValueError("num_points must be at least 8")
    rng = np.random.default_rng(seed)
    s = np.linspace(0.0, 1.0, num_points)

    if template_type == "bent_tube_centerline":
        points = np.column_stack([s - 0.5, 0.35 * (s - 0.5) ** 2, 0.15 * np.sin(np.pi * s)])
        radius = 0.08 * np.ones_like(s)
    elif template_type == "tapered_tube_centerline":
        points = np.column_stack([s - 0.5, 0.12 * np.sin(np.pi * s), 0.25 * (0.5 - s)])
        radius = 0.04 + 0.08 * (1.0 - s)
    elif template_type == "ellipsoid_medial_curve":
        angle = np.pi * (s - 0.5)
        points = np.column_stack([0.25 * np.cos(angle), 0.12 * np.sin(angle), 0.9 * (s - 0.5)])
        radius = 0.06 + 0.03 * np.cos(np.pi * s) ** 2
    elif template_type == "sine_deformed_tube":
        points = np.column_stack([s - 0.5, 0.18 * np.sin(2.0 * np.pi * s), 0.10 * np.cos(np.pi * s)])
        radius = 0.07 * np.ones_like(s)
    elif template_type == "Y_branch_centerline":
        trunk_n = num_points // 2
        branch_n = num_points - trunk_n
        s_trunk = np.linspace(0.0, 1.0, trunk_n, endpoint=False)
        s_branch = np.linspace(0.0, 1.0, branch_n)
        trunk = np.column_stack([np.zeros_like(s_trunk), np.zeros_like(s_trunk), s_trunk - 0.5])
        branch_left = np.column_stack([-0.35 * s_branch, np.zeros_like(s_branch), 0.1 + 0.4 * s_branch])
        branch_right = np.column_stack([0.35 * s_branch, np.zeros_like(s_branch), 0.1 + 0.4 * s_branch])
        points = np.concatenate([trunk, branch_left[: branch_n // 2], branch_right[branch_n // 2 :]], axis=0)
        radius = np.linspace(0.09, 0.05, points.shape[0])
    else:
        raise ValueError(f"Unknown template_type: {template_type}")

    noise = 0.01 * rng.normal(size=points.shape)
    points = _normalize(points + noise)
    tangent = _estimate_tangent(points)
    return {
        "points": points.astype(np.float32),
        "radius": radius.astype(np.float32),
        "tangent": tangent.astype(np.float32),
        "template_type": template_type,
        "meta": {"seed": seed},
    }


def _normalize(points: np.ndarray) -> np.ndarray:
    centered = points - np.mean(points, axis=0, keepdims=True)
    scale = np.max(np.linalg.norm(centered, axis=1))
    return centered / max(scale, 1e-8)


def _estimate_tangent(points: np.ndarray) -> np.ndarray:
    tangent = np.gradient(points, axis=0)
    norm = np.linalg.norm(tangent, axis=1, keepdims=True)
    return tangent / np.clip(norm, 1e-8, None)
