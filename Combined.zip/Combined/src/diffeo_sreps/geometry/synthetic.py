from __future__ import annotations

import numpy as np

from diffeo_sreps.geometry.srep import SRep


def make_ellipsoid_srep(
    n_atoms: int = 12,
    radii: tuple[float, float, float] = (1.0, 0.6, 0.35),
    seed: int = 0,
) -> SRep:
    """Create a simple 3D ellipsoid-like s-rep for tests and smoke experiments."""
    if n_atoms < 2:
        raise ValueError("n_atoms must be at least two")
    rng = np.random.default_rng(seed)
    z = np.linspace(-0.75, 0.75, n_atoms)
    theta = np.linspace(0.0, 2.0 * np.pi, n_atoms, endpoint=False)
    atoms = np.column_stack([0.25 * radii[0] * np.cos(theta), 0.25 * radii[1] * np.sin(theta), z])
    directions = rng.normal(size=(n_atoms, 2, 3))
    directions = directions / np.linalg.norm(directions, axis=-1, keepdims=True)
    local_scale = np.array(radii, dtype=float)
    spokes = 0.35 * directions * local_scale
    spokes[:, 1, :] *= -1.0
    return SRep(atoms=atoms, spokes=spokes)
