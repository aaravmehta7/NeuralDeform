from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class SRep:
    """Minimal skeletal representation.

    `atoms` are skeletal points. `spokes` are vectors from atoms to implied
    boundary samples. Multiple spokes per atom are supported with shape
    `(n_atoms, n_spokes, dim)`.
    """

    atoms: np.ndarray
    spokes: np.ndarray

    def __post_init__(self) -> None:
        atoms = np.asarray(self.atoms, dtype=float)
        spokes = np.asarray(self.spokes, dtype=float)
        if atoms.ndim != 2:
            raise ValueError("atoms must have shape (n_atoms, dim)")
        if spokes.ndim != 3:
            raise ValueError("spokes must have shape (n_atoms, n_spokes, dim)")
        if atoms.shape[0] != spokes.shape[0] or atoms.shape[1] != spokes.shape[2]:
            raise ValueError("atoms and spokes have incompatible shapes")
        object.__setattr__(self, "atoms", atoms)
        object.__setattr__(self, "spokes", spokes)

    @property
    def boundary_points(self) -> np.ndarray:
        return (self.atoms[:, None, :] + self.spokes).reshape(-1, self.atoms.shape[1])

    @property
    def radii(self) -> np.ndarray:
        return np.linalg.norm(self.spokes, axis=-1)

    def with_deformed_atoms(self, deformed_atoms: np.ndarray) -> "SRep":
        deformed_atoms = np.asarray(deformed_atoms, dtype=float)
        if deformed_atoms.shape != self.atoms.shape:
            raise ValueError("deformed_atoms must match atom shape")
        return SRep(atoms=deformed_atoms, spokes=self.spokes.copy())

    def transported(self, deformed_atoms: np.ndarray, deformed_boundary_points: np.ndarray) -> "SRep":
        """Create an s-rep from transported atoms and transported spoke endpoints."""
        deformed_atoms = np.asarray(deformed_atoms, dtype=float)
        deformed_boundary_points = np.asarray(deformed_boundary_points, dtype=float)
        if deformed_atoms.shape != self.atoms.shape:
            raise ValueError("deformed_atoms must match atom shape")
        expected_boundary_shape = (self.atoms.shape[0] * self.spokes.shape[1], self.atoms.shape[1])
        if deformed_boundary_points.shape != expected_boundary_shape:
            raise ValueError("deformed_boundary_points has incompatible shape")
        endpoints = deformed_boundary_points.reshape(self.spokes.shape)
        spokes = endpoints - deformed_atoms[:, None, :]
        return SRep(atoms=deformed_atoms, spokes=spokes)
