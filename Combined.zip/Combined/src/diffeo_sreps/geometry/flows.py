from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class SinusoidalObjectFlow:
    """Smooth synthetic flow that turns an ellipsoid into a wavy target object.

    This is a controlled stand-in for the inverse of a CMCF diffusion trajectory.
    It is not a physical CMCF simulator; it creates known diffeomorphic-ish stage
    maps that are useful for testing teacher generation and neural surrogates.
    """

    amplitude: float = 0.16
    twist: float = 0.45
    bend: float = 0.10
    n_integration_steps: int = 24

    def velocity(self, points: np.ndarray, stage_time: float = 1.0) -> np.ndarray:
        points = np.asarray(points, dtype=float)
        x = points[:, 0]
        y = points[:, 1]
        z = points[:, 2]
        envelope = 0.6 + 0.4 * stage_time
        return envelope * np.column_stack(
            [
                self.amplitude * np.sin(2.1 * z) + self.twist * y * z,
                self.amplitude * np.cos(1.7 * z) - self.twist * x * z,
                self.bend * np.sin(2.0 * x + 1.5 * y),
            ]
        )

    def transform(self, points: np.ndarray, time: float = 1.0) -> np.ndarray:
        points = np.asarray(points, dtype=float)
        x = points.copy()
        dt = float(time) / self.n_integration_steps
        for step in range(self.n_integration_steps):
            stage_time = step / max(self.n_integration_steps - 1, 1)
            x = x + dt * self.velocity(x, stage_time=stage_time)
        return x


def interpolate_stage_points(source: np.ndarray, target: np.ndarray, alpha: float) -> np.ndarray:
    """Synthetic CMCF-like stage interpolation from target alpha=1 to ellipsoid alpha=0."""
    source = np.asarray(source, dtype=float)
    target = np.asarray(target, dtype=float)
    if source.shape != target.shape:
        raise ValueError("source and target must have matching shapes")
    return (1.0 - alpha) * source + alpha * target
