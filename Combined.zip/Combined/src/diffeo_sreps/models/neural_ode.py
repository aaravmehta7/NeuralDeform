from __future__ import annotations


class MissingDeepDependencyError(ImportError):
    pass


try:
    import torch
    from torch import nn
except ImportError as exc:  # pragma: no cover - exercised only without torch installed
    torch = None
    nn = None
    _IMPORT_ERROR = exc
else:
    _IMPORT_ERROR = None


if nn is not None:

    class PointNetTargetEncoder(nn.Module):
        """PointNet-style encoder from target 3D points to a global latent code."""

        def __init__(self, point_dim: int = 3, latent_dim: int = 1024) -> None:
            super().__init__()
            self.point_mlp = nn.Sequential(
                nn.Linear(point_dim, 64),
                nn.ReLU(),
                nn.Linear(64, 128),
                nn.ReLU(),
                nn.Linear(128, 256),
                nn.ReLU(),
                nn.Linear(256, latent_dim),
            )

        def forward(self, target_points, target_mask=None):
            if target_points.ndim == 2:
                target_points = target_points.unsqueeze(0)
            per_point = self.point_mlp(target_points)
            if target_mask is not None:
                if target_mask.ndim == 1:
                    target_mask = target_mask.unsqueeze(0)
                mask = target_mask[..., None] > 0.5
                per_point = per_point.masked_fill(~mask, float("-inf"))
                latent = per_point.amax(dim=1)
                latent = torch.where(torch.isfinite(latent), latent, torch.zeros_like(latent))
                return latent
            return per_point.amax(dim=1)


    class VelocityFieldMLP(nn.Module):
        """Velocity network v_theta(t, x, z) for conditional Neural ODE transport."""

        def __init__(
            self,
            dim: int = 3,
            latent_dim: int = 1024,
            hidden_dim: int = 256,
            depth: int = 4,
            time_embedding: str = "scalar",
            stationary: bool = False,
        ) -> None:
            super().__init__()
            self.dim = dim
            self.time_embedding = time_embedding
            self.stationary = stationary
            time_dim = 0 if stationary or time_embedding == "none" else 1
            in_dim = dim + latent_dim + time_dim
            layers: list[nn.Module] = []
            for layer_index in range(depth):
                layers.append(nn.Linear(in_dim if layer_index == 0 else hidden_dim, hidden_dim))
                layers.append(nn.SiLU())
            layers.append(nn.Linear(hidden_dim, dim))
            self.net = nn.Sequential(*layers)

        def forward(self, t, x, latent):
            if x.ndim == 2:
                x = x.unsqueeze(0)
            if latent.ndim == 1:
                latent = latent.unsqueeze(0)
            pieces = [x]
            if not self.stationary and self.time_embedding != "none":
                t_value = torch.as_tensor(t, device=x.device, dtype=x.dtype)
                t_col = torch.ones(*x.shape[:-1], 1, device=x.device, dtype=x.dtype) * t_value
                pieces.append(t_col)
            latent_expanded = latent[:, None, :].expand(x.shape[0], x.shape[1], latent.shape[-1])
            pieces.append(latent_expanded)
            return self.net(torch.cat(pieces, dim=-1))


    class NeuralODERegistrationModel(nn.Module):
        """Conditional Neural ODE model with PointNet target encoder and velocity MLP."""

        def __init__(
            self,
            point_dim: int = 3,
            latent_dim: int = 1024,
            hidden_dim: int = 256,
            depth: int = 4,
            time_embedding: str = "scalar",
            stationary: bool = False,
        ) -> None:
            super().__init__()
            self.target_encoder = PointNetTargetEncoder(point_dim=point_dim, latent_dim=latent_dim)
            self.velocity_field = VelocityFieldMLP(
                dim=point_dim,
                latent_dim=latent_dim,
                hidden_dim=hidden_dim,
                depth=depth,
                time_embedding=time_embedding,
                stationary=stationary,
            )

        def encode_target(self, target_points, target_mask=None):
            return self.target_encoder(target_points, target_mask=target_mask)

        def velocity(self, t, x, latent):
            return self.velocity_field(t, x, latent)

        def forward(
            self,
            source_points,
            target_points,
            target_mask=None,
            n_steps: int = 8,
            method: str = "rk4",
            return_trajectory: bool = False,
        ):
            latent = self.encode_target(target_points, target_mask=target_mask)
            return integrate_velocity_field(
                self.velocity,
                source_points,
                latent,
                n_steps=n_steps,
                method=method,
                return_trajectory=return_trajectory,
            )


    class ConditionalMLPVelocityField(nn.Module):
        """Compatibility wrapper for older experiments that used an 8D condition vector."""

        def __init__(
            self,
            dim: int = 3,
            condition_dim: int = 8,
            hidden_dim: int = 128,
            depth: int = 4,
        ) -> None:
            super().__init__()
            self.velocity_field = VelocityFieldMLP(
                dim=dim,
                latent_dim=condition_dim,
                hidden_dim=hidden_dim,
                depth=depth,
                time_embedding="scalar",
                stationary=False,
            )

        def forward(self, t, x, condition):
            return self.velocity_field(t, x, condition)


    def integrate_velocity_field(velocity_model, points, latent, n_steps: int = 8, method: str = "rk4", return_trajectory: bool = False):
        """Integrate `dx/dt = v_theta(t, x, latent)` from t=0 to t=1."""
        if n_steps <= 0:
            raise ValueError("n_steps must be positive")
        x = points
        dt = 1.0 / n_steps
        trajectory = [x] if return_trajectory else None
        for step in range(n_steps):
            t = step * dt
            if method == "euler":
                x = x + dt * velocity_model(t, x, latent)
            elif method == "rk4":
                k1 = velocity_model(t, x, latent)
                k2 = velocity_model(t + 0.5 * dt, x + 0.5 * dt * k1, latent)
                k3 = velocity_model(t + 0.5 * dt, x + 0.5 * dt * k2, latent)
                k4 = velocity_model(t + dt, x + dt * k3, latent)
                x = x + (dt / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)
            else:
                raise ValueError("method must be 'euler' or 'rk4'")
            if return_trajectory:
                trajectory.append(x)
        if return_trajectory:
            return x, torch.stack(trajectory, dim=1)
        return x

else:

    class PointNetTargetEncoder:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs) -> None:
            raise MissingDeepDependencyError(
                "Install the deep extra with `python -m pip install -e .[deep]`."
            ) from _IMPORT_ERROR


    class VelocityFieldMLP:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs) -> None:
            raise MissingDeepDependencyError(
                "Install the deep extra with `python -m pip install -e .[deep]`."
            ) from _IMPORT_ERROR


    class NeuralODERegistrationModel:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs) -> None:
            raise MissingDeepDependencyError(
                "Install the deep extra with `python -m pip install -e .[deep]`."
            ) from _IMPORT_ERROR


    class ConditionalMLPVelocityField:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs) -> None:
            raise MissingDeepDependencyError(
                "Install the deep extra with `python -m pip install -e .[deep]`."
            ) from _IMPORT_ERROR


    def integrate_velocity_field(*args, **kwargs):  # type: ignore[no-redef]
        raise MissingDeepDependencyError(
            "Install the deep extra with `python -m pip install -e .[deep]`."
        ) from _IMPORT_ERROR
