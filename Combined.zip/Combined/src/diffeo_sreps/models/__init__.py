"""Optional neural deformation models."""
