from __future__ import annotations

import csv
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path

import numpy as np

from diffeo_sreps.data import SyntheticRegistrationDataset, generate_dataset_bundle, save_dataset_bundle
from diffeo_sreps.losses.registration import (
    jacobian_fold_loss,
    masked_point_mse,
    smoothness_loss,
    trajectory_mse,
)
from diffeo_sreps.models.neural_ode import (
    MissingDeepDependencyError,
    NeuralODERegistrationModel,
)
from diffeo_sreps.utils import load_yaml

try:
    import torch
    import torch.distributed as dist
    from torch.nn.parallel import DistributedDataParallel
    from torch.utils.data import DataLoader
    from torch.utils.data.distributed import DistributedSampler
except ImportError as exc:  # pragma: no cover - depends on local environment
    torch = None
    dist = None
    DistributedDataParallel = None
    DataLoader = None
    DistributedSampler = None
    _IMPORT_ERROR = exc
else:
    _IMPORT_ERROR = None


@dataclass(frozen=True)
class SyntheticNeuralODETrainConfig:
    n_objects: int = 0
    n_atoms: int = 0
    n_stages: int = 0
    validation_fraction: float = 0.0
    data_config_path: str | None = None
    latent_dim: int = 1024
    hidden_dim: int = 256
    depth: int = 4
    ode_steps: int = 12
    ode_method: str = "rk4"
    time_embedding: str = "scalar"
    stationary: bool = False
    batch_size: int = 64
    epochs: int = 50
    learning_rate: float = 1e-3
    weight_decay: float = 1e-5
    output_dir: str = "outputs/synthetic_neural_ode"
    device: str = "auto"
    distributed: bool = False
    num_workers: int = 0
    epoch_log_csv: str | None = None
    loss_weights: dict[str, float] = field(
        default_factory=lambda: {"point": 1.0, "traj": 0.0, "smooth": 0.01, "fold": 0.0, "inv": 0.0}
    )
    early_stopping_patience: int | None = None
    amp: bool = False
    seed: int = 0


@dataclass(frozen=True)
class TrainResult:
    output_dir: Path
    best_checkpoint: Path
    final_train_loss: float
    final_val_loss: float
    device: str
    distributed: bool


def train_synthetic_neural_ode(config: SyntheticNeuralODETrainConfig) -> TrainResult:
    if torch is None:
        raise MissingDeepDependencyError(
            "Install the deep extra with `python -m pip install -e .[deep]`."
        ) from _IMPORT_ERROR
    if config.data_config_path is None:
        raise ValueError("data_config_path must be provided for the presentation-aligned training pipeline")

    dist_state = _setup_distributed(config.distributed)
    device = _select_device(config.device, dist_state["local_rank"], dist_state["distributed"])
    torch.manual_seed(config.seed + dist_state["rank"])
    data_cfg = load_yaml(config.data_config_path)
    bundle = _ensure_bundle(data_cfg)

    output_dir = Path(config.output_dir)
    if dist_state["is_main"]:
        output_dir.mkdir(parents=True, exist_ok=True)
        if config.epoch_log_csv is not None:
            epoch_log_path = Path(config.epoch_log_csv)
            epoch_log_path.parent.mkdir(parents=True, exist_ok=True)
            with epoch_log_path.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=["epoch", "train_loss", "val_loss", "best_val"])
                writer.writeheader()
    _barrier(dist_state["distributed"])

    train_set = SyntheticRegistrationDataset(bundle["train"])
    val_set = SyntheticRegistrationDataset(bundle["val"])
    train_sampler = DistributedSampler(train_set, shuffle=True, seed=config.seed) if dist_state["distributed"] else None
    val_sampler = DistributedSampler(val_set, shuffle=False, seed=config.seed) if dist_state["distributed"] else None
    train_loader = DataLoader(
        train_set,
        batch_size=config.batch_size,
        shuffle=train_sampler is None,
        sampler=train_sampler,
        num_workers=config.num_workers,
        pin_memory=device.type == "cuda",
    )
    val_loader = DataLoader(
        val_set,
        batch_size=config.batch_size,
        shuffle=False,
        sampler=val_sampler,
        num_workers=config.num_workers,
        pin_memory=device.type == "cuda",
    )

    model = NeuralODERegistrationModel(
        point_dim=3,
        latent_dim=config.latent_dim,
        hidden_dim=config.hidden_dim,
        depth=config.depth,
        time_embedding=config.time_embedding,
        stationary=config.stationary,
    ).to(device)
    if dist_state["distributed"]:
        ddp_kwargs = {}
        if device.type == "cuda":
            ddp_kwargs["device_ids"] = [device.index]
            ddp_kwargs["output_device"] = device.index
        model = DistributedDataParallel(model, **ddp_kwargs)

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=config.learning_rate,
        weight_decay=config.weight_decay,
    )
    scaler = torch.amp.GradScaler(device.type, enabled=bool(config.amp and device.type == "cuda"))

    best_val = float("inf")
    final_train = float("inf")
    final_val = float("inf")
    best_checkpoint = output_dir / "best_model.pt"
    best_epoch = 0

    for epoch in range(1, config.epochs + 1):
        if train_sampler is not None:
            train_sampler.set_epoch(epoch)
        final_train = _run_epoch(
            model,
            train_loader,
            optimizer,
            scaler,
            config,
            device,
            training=True,
            distributed=dist_state["distributed"],
        )
        final_val = _run_epoch(
            model,
            val_loader,
            optimizer,
            scaler,
            config,
            device,
            training=False,
            distributed=dist_state["distributed"],
        )
        if dist_state["is_main"] and final_val < best_val:
            best_val = final_val
            best_epoch = epoch
            torch.save(
                {
                    "model_state_dict": _unwrap_model(model).state_dict(),
                    "config": _checkpoint_config(config),
                    "epoch": epoch,
                    "val_loss": final_val,
                },
                best_checkpoint,
            )
        if dist_state["is_main"]:
            print(
                f"epoch={epoch:04d} train_loss={final_train:.8e} "
                f"val_loss={final_val:.8e} best_val={best_val:.8e}",
                flush=True,
            )
            if config.epoch_log_csv is not None:
                with Path(config.epoch_log_csv).open("a", newline="", encoding="utf-8") as handle:
                    writer = csv.DictWriter(handle, fieldnames=["epoch", "train_loss", "val_loss", "best_val"])
                    writer.writerow(
                        {
                            "epoch": epoch,
                            "train_loss": final_train,
                            "val_loss": final_val,
                            "best_val": best_val,
                        }
                    )
        if config.early_stopping_patience is not None and epoch - best_epoch >= config.early_stopping_patience:
            if dist_state["is_main"]:
                print(f"event=early_stop epoch={epoch} best_epoch={best_epoch}", flush=True)
            break

    if dist_state["is_main"]:
        torch.save(
            {
                "model_state_dict": _unwrap_model(model).state_dict(),
                "config": _checkpoint_config(config),
                "epoch": epoch,
                "train_loss": final_train,
                "val_loss": final_val,
            },
            output_dir / "last_model.pt",
        )
    _barrier(dist_state["distributed"])
    _cleanup_distributed(dist_state["distributed"])

    return TrainResult(
        output_dir=output_dir,
        best_checkpoint=best_checkpoint,
        final_train_loss=float(final_train),
        final_val_loss=float(final_val),
        device=str(device),
        distributed=bool(dist_state["distributed"]),
    )


def _run_epoch(model, loader, optimizer, scaler, config, device, training: bool, distributed: bool) -> float:
    model.train(training)
    total_loss = torch.zeros((), device=device)
    total_items = torch.zeros((), device=device)
    autocast_enabled = bool(config.amp and device.type == "cuda")
    needs_grad = training or config.loss_weights.get("smooth", 0.0) > 0.0 or config.loss_weights.get("fold", 0.0) > 0.0
    context = torch.enable_grad() if needs_grad else torch.no_grad()
    with context:
        for batch in loader:
            source = batch["source_points"].to(device)
            target = batch["target_points"].to(device)
            target_mask = batch["target_mask"].to(device)
            traj_gt = batch["traj_gt"].to(device)
            integration_steps = int(traj_gt.shape[1] - 1) if config.loss_weights.get("traj", 0.0) > 0.0 else int(config.ode_steps)
            with torch.amp.autocast(device_type=device.type, enabled=autocast_enabled):
                latent = _unwrap_model(model).encode_target(target, target_mask=target_mask)
                predicted, predicted_traj = model(
                    source,
                    target,
                    target_mask=target_mask,
                    n_steps=integration_steps,
                    method=config.ode_method,
                    return_trajectory=True,
                )
                loss = config.loss_weights.get("point", 1.0) * masked_point_mse(predicted, target, target_mask)
                if config.loss_weights.get("traj", 0.0) > 0.0:
                    loss = loss + config.loss_weights["traj"] * trajectory_mse(predicted_traj, traj_gt)
                if config.loss_weights.get("smooth", 0.0) > 0.0:
                    loss = loss + config.loss_weights["smooth"] * smoothness_loss(_unwrap_model(model), source, latent)
                if config.loss_weights.get("fold", 0.0) > 0.0:
                    loss = loss + config.loss_weights["fold"] * jacobian_fold_loss(
                        _unwrap_model(model),
                        source,
                        latent,
                        ode_steps=integration_steps,
                    )
            if training:
                optimizer.zero_grad(set_to_none=True)
                scaler.scale(loss).backward()
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                scaler.step(optimizer)
                scaler.update()
            batch_size = source.shape[0]
            total_loss += loss.detach() * batch_size
            total_items += batch_size
    if distributed:
        dist.all_reduce(total_loss, op=dist.ReduceOp.SUM)
        dist.all_reduce(total_items, op=dist.ReduceOp.SUM)
    return float((total_loss / torch.clamp(total_items, min=1)).detach().cpu())


def _ensure_bundle(data_cfg: dict) -> dict[str, dict]:
    output_path = Path(data_cfg["output_path"])
    if output_path.exists():
        raw = np.load(output_path, allow_pickle=True)
        bundle: dict[str, dict] = {}
        for flat_key in raw.files:
            split, key = flat_key.split("__", 1)
            bundle.setdefault(split, {})[key] = raw[flat_key]
        return bundle
    bundle = generate_dataset_bundle(data_cfg)
    save_dataset_bundle(bundle, output_path)
    return bundle


def _checkpoint_config(config: SyntheticNeuralODETrainConfig) -> dict:
    fields = asdict(config)
    return {
        "latent_dim": fields["latent_dim"],
        "hidden_dim": fields["hidden_dim"],
        "depth": fields["depth"],
        "ode_steps": fields["ode_steps"],
        "ode_method": fields["ode_method"],
        "time_embedding": fields["time_embedding"],
        "stationary": fields["stationary"],
    }


def _select_device(requested: str, local_rank: int, distributed: bool):
    if requested == "auto":
        if torch.cuda.is_available():
            index = local_rank if distributed else 0
            torch.cuda.set_device(index)
            return torch.device("cuda", index)
        return torch.device("cpu")
    if requested.startswith("cuda") and torch.cuda.is_available():
        device = torch.device(requested)
        torch.cuda.set_device(device)
        return device
    return torch.device(requested)


def _setup_distributed(requested: bool) -> dict[str, int | bool]:
    world_size = int(os.environ.get("WORLD_SIZE", "1"))
    distributed = bool(requested or world_size > 1)
    if not distributed:
        return {"distributed": False, "rank": 0, "local_rank": 0, "is_main": True}

    if dist is None:
        raise MissingDeepDependencyError("PyTorch distributed is unavailable in this environment.")
    backend = "nccl" if torch.cuda.is_available() else "gloo"
    if not dist.is_initialized():
        dist.init_process_group(backend=backend)
    rank = dist.get_rank()
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    return {
        "distributed": True,
        "rank": rank,
        "local_rank": local_rank,
        "is_main": rank == 0,
    }


def _barrier(distributed: bool) -> None:
    if distributed and dist is not None and dist.is_initialized():
        dist.barrier()


def _cleanup_distributed(distributed: bool) -> None:
    if distributed and dist is not None and dist.is_initialized():
        dist.destroy_process_group()


def _unwrap_model(model):
    if DistributedDataParallel is not None and isinstance(model, DistributedDataParallel):
        return model.module
    return model
