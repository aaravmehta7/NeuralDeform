"""Training entry points."""

from diffeo_sreps.training.synthetic_neural_ode import (
    SyntheticNeuralODETrainConfig,
    TrainResult,
    train_synthetic_neural_ode,
)

__all__ = [
    "SyntheticNeuralODETrainConfig",
    "TrainResult",
    "train_synthetic_neural_ode",
]
