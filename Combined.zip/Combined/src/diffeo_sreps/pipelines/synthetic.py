from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from diffeo_sreps.data import make_synthetic_ellipsoid_to_object_trajectory
from diffeo_sreps.data.synthetic_trajectory import TeacherPair
from diffeo_sreps.pipelines.base import PipelineArtifacts


@dataclass(frozen=True)
class SyntheticEvolutionarySRepWrapper:
    """Pipeline-compatible wrapper for synthetic ellipsoid-to-object experiments."""

    n_atoms: int = 8
    n_stages: int = 8
    seed: int = 0

    def run(
        self,
        input_path: Path | None = None,
        output_dir: Path | None = None,
        object_id: str | None = None,
    ) -> PipelineArtifacts:
        object_id = object_id or "synthetic_0000"
        work_dir = output_dir or Path("outputs/synthetic") / object_id
        trajectory = make_synthetic_ellipsoid_to_object_trajectory(
            n_atoms=self.n_atoms,
            n_stages=self.n_stages,
            seed=self.seed,
        )
        teacher_pairs = tuple(
            TeacherPair(
                source=source,
                target=target,
                source_time=float(trajectory.stage_times[pair_index + 1]),
                target_time=float(trajectory.stage_times[pair_index]),
                object_id=object_id,
                pair_id=f"{object_id}_stage_{pair_index + 1:02d}_to_{pair_index:02d}",
            )
            for pair_index, (source, target) in enumerate(trajectory.backward_pairs)
        )
        return PipelineArtifacts(
            object_id=object_id,
            work_dir=work_dir,
            ellipsoid_srep=trajectory.ellipsoid,
            target_srep=trajectory.target,
            cmcf_stages=trajectory.stages,
            teacher_pairs=teacher_pairs,
        )
