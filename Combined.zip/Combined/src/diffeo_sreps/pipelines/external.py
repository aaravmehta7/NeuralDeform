from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from diffeo_sreps.pipelines.base import ExternalPipelineUnavailable, PipelineArtifacts


@dataclass(frozen=True)
class ExternalEvolutionarySRepWrapper:
    """Placeholder adapter for SlicerSALT/Deformetrica-style evolutionary outputs.

    Expected future responsibilities:

    - launch a prebuilt pipeline or consume an existing output folder,
    - parse CMCF stages, ellipsoid s-rep, final s-rep, and LDDMM maps,
    - normalize them into `PipelineArtifacts`,
    - cache teacher pairs for neural ODE training.
    """

    executable: Path | None = None

    def run(self, input_path: Path, output_dir: Path, object_id: str | None = None) -> PipelineArtifacts:
        if self.executable is None or not self.executable.exists():
            raise ExternalPipelineUnavailable(
                "External evolutionary s-rep pipeline is not configured yet. "
                "Use SyntheticEvolutionarySRepWrapper for the first experiments."
            )
        raise NotImplementedError(
            "External pipeline parsing is intentionally deferred until the output format is known."
        )
