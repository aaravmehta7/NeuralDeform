from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from diffeo_sreps.data import TeacherPair
from diffeo_sreps.geometry import SRep


class ExternalPipelineUnavailable(RuntimeError):
    """Raised when a requested external pipeline binary or output is unavailable."""


@dataclass(frozen=True)
class PipelineArtifacts:
    """Common outputs expected from an evolutionary s-rep pipeline run."""

    object_id: str
    work_dir: Path
    ellipsoid_srep: SRep
    target_srep: SRep | None
    cmcf_stages: tuple[SRep, ...]
    teacher_pairs: tuple[TeacherPair, ...]


class PipelineWrapper(Protocol):
    """Interface implemented by synthetic and external pipeline adapters."""

    def run(self, input_path: Path, output_dir: Path, object_id: str | None = None) -> PipelineArtifacts:
        """Run or load a pipeline and return normalized artifacts."""
