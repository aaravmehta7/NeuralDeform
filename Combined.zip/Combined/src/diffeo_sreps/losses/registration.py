from __future__ import annotations


try:
    import torch
except ImportError as exc:  # pragma: no cover - depends on local environment
    torch = None
    _IMPORT_ERROR = exc
else:
    _IMPORT_ERROR = None


def _require_torch():
    if torch is None:
        raise ImportError("PyTorch is required for registration losses.") from _IMPORT_ERROR


def masked_point_mse(predicted, target, mask=None):
    _require_torch()
    if mask is None:
        return torch.mean((predicted - target) ** 2)
    weights = mask[..., None].to(predicted.dtype)
    denom = torch.clamp(weights.sum() * predicted.shape[-1], min=1.0)
    return torch.sum(((predicted - target) ** 2) * weights) / denom


def trajectory_mse(predicted_traj, target_traj):
    _require_torch()
    return torch.mean((predicted_traj - target_traj) ** 2)


def smoothness_loss(model, source_points, latent, sample_stride: int = 8):
    _require_torch()
    sampled = source_points[:, :: max(1, sample_stride), :].detach().clone().requires_grad_(True)
    velocity = model.velocity(0.5, sampled, latent)
    grad_terms = []
    for axis in range(velocity.shape[-1]):
        grads = torch.autograd.grad(
            velocity[..., axis].sum(),
            sampled,
            create_graph=True,
            retain_graph=True,
        )[0]
        grad_terms.append(torch.mean(grads**2))
    return sum(grad_terms) / max(len(grad_terms), 1)


def jacobian_fold_loss(model, source_points, latent, ode_steps: int, sample_stride: int = 8, eps: float = 1e-4):
    _require_torch()
    sampled = source_points[:, :: max(1, sample_stride), :].detach().clone().requires_grad_(True)
    velocity = model.velocity(0.5, sampled, latent)
    jac_rows = []
    for axis in range(velocity.shape[-1]):
        grads = torch.autograd.grad(
            velocity[..., axis].sum(),
            sampled,
            create_graph=True,
            retain_graph=True,
        )[0]
        jac_rows.append(grads)
    jac = torch.stack(jac_rows, dim=-2)
    identity = torch.eye(3, device=jac.device, dtype=jac.dtype).view(1, 1, 3, 3)
    local_map = identity + jac / max(int(ode_steps), 1)
    det = torch.linalg.det(local_map)
    return torch.mean(torch.relu(eps - det))
