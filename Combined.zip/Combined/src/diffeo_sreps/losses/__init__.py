"""Loss helpers for the proof-of-concept trainer."""

from diffeo_sreps.losses.registration import (
    jacobian_fold_loss,
    masked_point_mse,
    smoothness_loss,
    trajectory_mse,
)

__all__ = [
    "jacobian_fold_loss",
    "masked_point_mse",
    "smoothness_loss",
    "trajectory_mse",
]
